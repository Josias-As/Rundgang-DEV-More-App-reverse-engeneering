# ENTSCHEIDUNGEN – Rundgangs-App (Bau-Phase)

Ergänzt `RG-D1–D15` im Vault (`Rundgang/01_Planung_2026-10-25/02_ENTSCHEIDUNGEN_UND_FRAGEN.md`). Kennzeichnung: belegt / geschlussfolgert / UNSICHER.

## Technik
- **E-01 Refresh vor jedem Frisch-Lesen** (belegt): Power Apps beantwortet identische Abfragen aus dem Sitzungs-Cache (D1 zeigte nach REST-Änderung den alten Status). `Refresh(...)` vor SS1/SS2/SS3 und in OnVisible. Im Livemonitor erzeugt `Refresh` selbst keinen Netzaufruf (belegt), kostet also nichts.
- **E-02 Leere Zeilen aus `Ungroup` filtern** (belegt): Kategorien ohne n.i.O. ergaben eine Leerzeile. Nur Kategorien mit `AnzahlNIO > 0` und `!IsBlank(PruefpunktID)`.
- **E-03 Typsichere Fehlerbehandlung**: `IfError(Patch(...), Set(...))` in einem `If`-Zweig ergab „Ungültiger Argumenttyp (Boolean) … Record erwartet“ (belegt). Muster stattdessen `If(Bedingung && IsError(Patch(...)), Set(varPatchFehler, true))` bzw. `If(IsError(ClearCollect(...)), Clear(...))`.
- **E-04 YAML = Studio-Export**: Nach jeder Änderung Screen-Code über „Ansichtscode → Code kopieren → /empfang“ zurückgeholt und mit `vergleiche_yaml.js` geprüft (zuletzt 0 Unterschiede). Studio lässt Standardwerte weg.
- **E-05 Y-Formeln in Galerien mit flexibler Höhe** (belegt): beim YAML-Einfügen teils eingefroren → nach dem Einfügen per Formelleiste prüfen/setzen. Die Studio-Zeichenfläche zeigt flexible Höhen falsch, nur die Vorschau zählt.
- **E-06 `varPatchFehler` nur als Zusatzhinweis**: Erfolg/Misserfolg entscheidet immer die Nachlese; die Variable ergänzt die Fehlermeldung („SharePoint hat einen Schreibfehler gemeldet“).
- **E-07 Barrierefreiheit: 57 Hinweise an Anzeige-Labels bewusst belassen** (geschlussfolgert, Ursache UNSICHER): „Fehlender Tabstopp“/„Fokus wird nicht angezeigt“ an reinen Text-Labels (OnSelect = false, TabIndex = −1). Ein TabIndex ≥ 0 würde Bildschirmleser durch jede Beschriftung führen. Alle Eingaben/Galerien/Dropdowns haben eine barrierefreie Bezeichnung (8 behoben).
- **E-08 Leistung: 7 Hinweise „Sammlung initialisiert, aber nie verwendet“ bewusst belassen** (belegt falsch-positiv, z. B. colDurchTag/colErgTag werden in galStartRundgaenge.Items gelesen). Hilfssammlungen innerhalb einer Schreibformel sind Absicht (Nachlese/Abgleich).

## Befunde Prüf-Agent (R19, 25.10.2026) und Umgang
| # | Befund | Umgang |
|---|---|---|
| 1 hoch | Abschluss prüfte Vollständigkeit gegen evtl. leeres `colKatListe` | **behoben**: SS3 baut die Liste aus der frisch gelesenen `KategorieListe` neu und verlangt `Anzahl = AnzahlKategorien > 0`; Knopf gesperrt bei leerer Liste; OnVisible meldet unvollständige Liste |
| 2 hoch/mittel | Wettlauf Abschluss ↔ Speichern; fehlgeschlagener Statuswechsel übergangen | **behoben**: erst `Abschluss` setzen und per Nachlese bestätigen (sonst Abbruch), dann Ergebnisse lesen; vor `Abgeschlossen` Ergebnisse erneut lesen und `ID@GespeichertAm` vergleichen – bei Änderung Abbruch mit „erneut tippen“ (wiederholbar) |
| 3 mittel | Keine Plausibilität der Soll-Mängel | **behoben**: `Sum(AnzahlNIO) = CountRows(colMaengelSoll)` Pflicht, sonst Abbruch mit Meldung; Parsen in `IsError` gefasst |
| 4 mittel | Nachlese ohne Refresh | **behoben**: Refresh vor jeder Nachlese in SS1, SS2, SS3 |
| 5 mittel/niedrig | Prüfpunkt nach Speichern deaktiviert → Antwort fällt beim erneuten Speichern weg; Nur-Ansicht zeigt heutige Stammdaten | **offen, bewusst** (V1.1): Stammdaten werden nicht während laufender Rundgänge gepflegt (Regel für die Pflege-Rolle, FRAGEN F4). Mängel tragen die Fragetext-Kopie. |
| 6 niedrig | Kategorie ohne aktive Prüfpunkte | **behoben in SS2**: Speichern verweigert mit Hinweis „keine aktiven Prüfpunkte“. SS1-Filter nicht ergänzt (wäre 2000er-Grenze über RG_Pruefpunkte). |
| 7 niedrig | Zahl-Bewertung nicht neu berechnet; `Value("-")` | **behoben**: OnVisible bewertet ZAHL neu (außer Nur-Ansicht); `IfError(Value(Self.Text), Blank())` |
| 8 niedrig | Mitternacht bei NachholTage = 0 | **offen**: Konfiguration steht auf 1 (gestern bleibt erreichbar). Fachfrage F3. |
| 9 niedrig | Delegation `Filter(RG_Kategorien, Aktiv)` max. 2000 | **akzeptiert**: realistisch < 200 Kategorien gesamt. |
| 10 niedrig | Konfliktfenster gleiche Sekunde | **akzeptiert**: GespeichertAm ist sekundengenau (belegt per REST), Restfenster < 1 s, Nutzer wird informiert. |

## Prüfung der Pakete (26.10.2026, zweiter unabhängiger Prüfer) – Umgang
| # | Befund | Umgang |
|---|---|---|
| 1 | Automatisches Archivieren scheiterte stumm an der 2-s-Sperre aus dem Abschluss | behoben: Timer hebt die Sperre vor `Select` auf; `varArchivStart` vor `Navigate` zurückgesetzt |
| 2 | Admin-Reset konnte einen gerade laufenden Abschluss zerstören; löschte auch bearbeitete Mängel | behoben: Reset erst 5 Min. nach letzter Änderung; nur Mängel mit Status „Offen“; SS3 (FA) prüft vor „Abgeschlossen“ den Status frisch |
| 3 | Umlaute im PDF (fehlender Zeichensatz) | behoben: Flow umschließt das HTML mit `<meta charset="utf-8">` |
| 4 | Foto-Fenster im Querformat zu klein | behoben: Kartenhöhe `Min(Parent.Height - 32, 680)`, zentriert, Mindesthöhe der Fotoliste |
| 5 | Ausgeblendete n.i.O.-Antworten deaktivierter Prüfpunkte werden beim Abschluss zu Mängeln | **bewusst so belassen**: der Befund war am Tag der Prüfung real; Zählung (AnzahlNIO) und Mängel sind konsistent |
| 6 | „TESTMODUS“ dauerhaft im archivierten PDF | behoben: Kennzeichnung nach `TestDatensatz` des Rundgangs („TESTDATEN“), nicht nach der Konfiguration |
| 7 | Doppelte Fotos bei Wiederholung; Fotos für später i.O. gesetzte Punkte | behoben: Dateiname mit GUID bei Aufnahme festgelegt; Upload nur für Punkte, die beim Speichern n.i.O. sind |
| 8 | Galerie-Sprung über `varSprungZu` konnte bei Eingaben erneut springen | behoben: `Default` hängt an einer Datensatz-Variable (`varSprungRec`), die sich nur beim gewollten Sprung ändert |
| 9 | CP4 zeigte bei gewähltem Nachholtag auch den heutigen Rundgang | behoben: nur `DateValue(TagText) < varHeute` |
| 10 | Apostroph bricht HTML-Links/Dateinamen | behoben: `fnHtml` maskiert `'` und `"`, `fnDateiname` entfernt `'` |
| 11 | Flow-Hinweise (Datei vorhanden, RG_Temp, Parameterreihenfolge), CP3-Schritt doppelt | behoben bzw. als UNSICHER im Paket markiert: Archivname mit Uhrzeit, RG_Temp einmalig anlegen, Reihenfolge per Studio-Vorschlag prüfen; CP3-Schritt 2 entfernt |

- **E-09 (26.10.2026, Josias): CP3 Schnellknopf "Offene auf i.O." verworfen.** Pruefer sind nicht immer verantwortungsbewusst (Fantasietexte wie 'gzgz'); der Zwang, jeden Punkt bewusst zu beantworten, ist gewollt. Keine Funktionen, die das Durchklicken erleichtern. Ideen stattdessen als Kontrollen (Mindestlaenge Kommentar, Foto-/QR-Nachweis, Auffaelligkeit bei sehr kurzer Dauer).
