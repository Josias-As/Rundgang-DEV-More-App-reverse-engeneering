# Code-Pakete – nächste Änderungen der Rundgang-App

Stand 26.10.2026 · passend zum App-Stand vom 25.10. (Namen exakt wie in deiner App). Gesamtreihenfolge mit den anderen Paketen: **CP0 → CP1 → K → CP3 → CP4 → FA → CP2** (CP2 erst nach Outlook-Verbindung).

**So fügst du ein (gilt für alle Pakete)**
- **YAML-Bausteine** (`pakete\fertig\*.yaml`): Datei im Editor öffnen → Strg+A → Strg+C → in Studio das Ziel im Baum markieren (steht beim Paket) → Strg+V. Die YAML ist in „Datei-Schreibweise“ (Kommas) – das ist richtig so, Studio übersetzt beim Einfügen selbst.
- **Formeln in der Formelleiste**: immer die hier abgedruckte **deutsche** Fassung (Semikolons) nehmen. Eigenschaft oben links auswählen, Formelleiste Strg+A, einfügen.
- **Vorher**: Vorschau beenden. **Nachher**: App-Überprüfung → Formeln = 0, dann speichern (Strg+S).
- Landet ein Baustein außerhalb des gewünschten Containers: im Baum Rechtsklick → Ausschneiden, Container markieren → Einfügen.

---

## CP0 – Vorbereitung (1 Minute, Pflicht vor CP1–CP3)

**App → OnStart**: ans Ende der vorhandenen Formel anhängen (vor der letzten Zeile ein `;;` setzen, falls die letzte Zeile keins hat):
```
Set(varAlleIOFrage; false);;
Set(varProtokollZeit; Now());;
```
**App → Formulas**: ans Ende anhängen:
```
fnHtml(t: Text): Text = Substitute(Substitute(Substitute(Substitute(Substitute(t; "&"; "&amp;"); "<"; "&lt;"); ">"; "&gt;"); """"; "&quot;"); "'"; "&#39;");;
```
Danach oben „…“ → „OnStart ausführen“ (oder App einmal neu laden), damit die Variablen existieren.

---

## CP1 – Protokoll-Screen (ohne Freigabe machbar, ca. 15 Minuten)

**Nutzen:** Nach dem Abschluss sieht der Prüfer ein sauberes Protokoll aller Antworten (Mängel rot). Genau dieser Inhalt wird später in CP2 per Mail verschickt.

1. **Screen einfügen:** `fertig\CP1_scrProtokoll.yaml` kopieren → im Baum **scrRundgang** markieren → Strg+V. Es entsteht `scrProtokoll` (Kopf, Inhaltsbereich `conPrInhalt`, Fuß mit Mail-Status, Lade-Overlay).
   - Falls `LayoutOverflowY` beim Einfügen bemängelt wird: Zeile löschen und bei `conPrInhalt` rechts im Eigenschaftenbereich **Vertikaler Überlauf = Scrollen** setzen.
2. **HTML-Steuerelement:** `conPrInhalt` markieren → Einfügen → **HTML-Text** → umbenennen in **htmProtokoll**. Eigenschaften:
   - `AutoHeight` (Automatische Höhe) = `true`
   - `Width` = `Parent.Width - 32`
   - `PaddingTop/Bottom/Left/Right` = `0`
   - `HtmlText` =
```
With({d: varDurch};
    "<div style='font-family:Segoe UI,Arial,sans-serif;font-size:14px;color:#1B1B1F'>" &
    "<div style='background:#171496;color:#ffffff;padding:14px 16px'>" &
        "<div style='font-size:20px;font-weight:600'>" & fnHtml(d.RundgangName) & "</div>" &
        "<div>" & fnTagAnzeige(DateValue(d.TagText)) & " · Prüfer: " & fnHtml(d.PrueferName) & "</div>" &
        "<div>Status: " & d.Status & " · Beginn " & Text(d.StartZeit; "hh:mm") & If(IsBlank(d.EndeZeit); ""; " · Ende " & Text(d.EndeZeit; "hh:mm")) & " · <b>" & Coalesce(d.AnzahlNIO; 0) & " n.i.O.</b></div>" &
    "</div>" &
    Concat(Sort(colErgProt; Position) As e;
        "<h3 style='margin:18px 0 6px 0;font-size:16px;color:#171496'>" & e.Position & ". " & fnHtml(e.KategorieName) &
        " <span style='font-weight:400;color:#5F6370;font-size:13px'>" & fnHtml(e.BereichName) & " · " & fnHtml(e.PrueferName) & " · " & Text(e.GespeichertAm; "hh:mm") & "</span></h3>" &
        "<table style='width:100%;border-collapse:collapse;table-layout:fixed'>" &
        Concat(Table(ParseJSON(e.Antworten)) As a;
            With({b: Text(a.Value.Bewertung); k: Text(a.Value.Kommentar)};
                "<tr style='border-bottom:1px solid #DADCE5;" & If(b = "NIO"; "background:#FCE8E6;"; "") & "'>" &
                "<td style='padding:6px 8px;width:46%'>" & fnHtml(Text(a.Value.Frage)) & "</td>" &
                "<td style='padding:6px 8px;width:64px;white-space:nowrap;font-weight:600;color:" & If(b = "NIO"; "#B3261E"; "#0F7B3F") & "'>" & Switch(b; "IO"; "i.O."; "NIO"; "n.i.O."; "") & "</td>" &
                "<td style='padding:6px 8px'>" & fnHtml(Text(a.Value.WertText)) & If(IsBlank(a.Value.WertZahl); ""; Text(Value(a.Value.WertZahl)) & " " & fnHtml(Text(a.Value.Einheit))) &
                If(IsBlank(k) || k = ""; ""; "<br><i style='color:#B3261E'>" & fnHtml(k) & "</i>") & "</td></tr>"
            )
        ) & "</table>"
    ) &
    "<p style='color:#5F6370;font-size:12px;margin-top:18px'>Erstellt mit der Rundgang-App · " & Text(varProtokollZeit; "dd.mm.yyyy hh:mm") & If(d.TestDatensatz; " · TESTDATEN"; "") & "</p></div>"
)
```
3. **Knopf in der Übersicht:** `fertig\CP1_btnRuProtokoll.yaml` kopieren → im Baum **conRuKopf** (scrRundgang) markieren → Strg+V. Erscheint nur bei abgeschlossenen Rundgängen oben rechts „Protokoll ›“.

**Test:** Rundgang abschließen → „Protokoll ›“ → alle Kategorien, n.i.O. rot mit Kommentar, Zahl mit Einheit (18,5 °C), Fuß „noch nicht per Mail versendet“. Text mit `<` oder `&` im Kommentar wird korrekt angezeigt (fnHtml).
**Rückweg:** scrProtokoll und btnRuProtokoll löschen; fnHtml und die zwei OnStart-Zeilen stören nicht.

---

## CP2 – Protokoll-Mail (SS4) – **erst nach Freigabe**

**Voraussetzung:** Daten → Daten hinzufügen → **Office 365 Outlook** (Standard-Konnektor) mit deinem Konto. Der Name in der App ist dann `Office365Outlook`. RG_Konfiguration: Testmodus = Ja, Testadresse = deine Adresse (steht schon so).

1. `fertig\CP2_btnPrSenden.yaml` kopieren → im Baum **conPrFuss** (scrProtokoll) markieren → Strg+V. Knopf rechts im Fuß „Per Mail senden“ / „Erneut senden“.
2. Die Formel (OnSelect) ist schon drin; deutsche Fassung zum Prüfen/Nachtragen:
```
If(!varIsLoading && Now() >= varSperreBis;
    Set(varIsLoading; true);;
    Set(varPatchFehler; false);;
    Refresh(RG_Durchfuehrungen);;
    Set(varDurch; LookUp(RG_Durchfuehrungen; ID = varDurchID));;
    With({an: If(cfgTestmodus; cfgTestadresse; cfgEmpfaenger);
          betreff: If(cfgTestmodus; "TEST – "; "") & "Rundgangsprotokoll " & varDurch.RundgangName & " · " & Text(DateValue(varDurch.TagText); "dd.mm.yyyy") & If(Coalesce(varDurch.AnzahlNIO; 0) > 0; " · " & varDurch.AnzahlNIO & " Mängel"; "")};
        If(
            varDurch.Status <> stAbgeschlossen;
                Notify("Das Protokoll kann erst nach dem Abschluss versendet werden."; NotificationType.Warning);
            IsBlank(an);
                Notify("In RG_Konfiguration ist kein Empfänger hinterlegt (" & If(cfgTestmodus; "Testadresse"; "Empfaenger") & ")."; NotificationType.Error);
            IsError(Office365Outlook.SendEmailV2(an; betreff; htmProtokoll.HtmlText; {Importance: If(Coalesce(varDurch.AnzahlNIO; 0) > 0; "High"; "Normal")}));
                Notify("Das Protokoll wurde nicht versendet. Bitte erneut tippen."; NotificationType.Error);
            If(IsError(Patch(RG_Durchfuehrungen; LookUp(RG_Durchfuehrungen; ID = varDurchID); {MailGesendetAm: Now()})); Set(varPatchFehler; true));;
            Refresh(RG_Durchfuehrungen);;
            Set(varDurch; LookUp(RG_Durchfuehrungen; ID = varDurchID));;
            Notify("Protokoll gesendet an " & an & If(IsBlank(varDurch.MailGesendetAm); " – der Versandzeitpunkt konnte nicht gespeichert werden."; "."); NotificationType.Success)
        )
    );;
    Set(varSperreBis; DateAdd(Now(); 2; TimeUnit.Seconds));;
    Set(varIsLoading; false)
)
```
**Was sie tut:** Zweifach-Sperre gegen Doppeltippen · liest den Rundgang frisch · nur bei „Abgeschlossen“ · Empfänger aus der Konfiguration (Testmodus → Testadresse, Betreff beginnt mit „TEST –“, fehlt die Zeile „Testmodus“, gilt trotzdem Testmodus) · Mängel → Wichtigkeit hoch · danach `MailGesendetAm` setzen und nachlesen.
**Test:** einmal senden → Mail kommt an, Fuß zeigt „Versendet am …“; Doppeltipp → nur eine Mail; Testadresse in der Konfiguration leeren → Fehlermeldung statt Versand.
**Rückweg:** btnPrSenden löschen; Outlook-Datenquelle entfernen.

---

## CP3 – Schnellknopf „Offene auf i.O.“ – **VERWORFEN (26.10.2026, Josias): nicht einbauen**

> Grund: Die Prüfer sind nicht immer verantwortungsbewusst. Heute werden schon Felder mit „gzgz“ gefüllt. Der Knopf würde das Durchklicken zusätzlich erleichtern und Mängel verdecken. Der Zwang, jeden Punkt bewusst zu beantworten, ist gewollt. (Der Rest dieses Abschnitts bleibt nur zur Dokumentation.)

## (verworfen) CP3 – Schnellknopf – ca. 5 Minuten, erst nach Paket K

> Die Formeln nutzen das Feld `Inaktiv` aus Paket K (ausgeblendete Antworten deaktivierter Prüfpunkte werden nicht angefasst). Deshalb CP3 erst nach K einbauen.

**Nutzen:** Bei Kategorien mit vielen Prüfpunkten, die fast immer in Ordnung sind: erst die Auffälligen auf n.i.O. setzen, dann alle übrigen mit einem Knopf auf i.O. – mit Sicherheitsabfrage (zweites Tippen). Zahl/Auswahl/Text bleiben unberührt.

1. `fertig\CP3_btnKaAlleIO.yaml` kopieren → im Baum **conKaKopf** (scrKategorie) markieren → Strg+V. Knopf oben rechts im Kopf, nur sichtbar, wenn noch offene i.O./n.i.O.-Punkte da sind und nicht „nur Ansicht“. (Das Zurücksetzen der Sicherheitsabfrage beim Öffnen ist schon im OnVisible aus Paket K enthalten.)
**Test:** Kategorie mit 2 offenen Punkten → „Offene 2 auf i.O.“ → 1. Tippen: grün „Wirklich 2 × i.O.? Erneut tippen“ → 2. Tippen: beide i.O., Knopf verschwindet; Zurück fragt „Verwerfen?“ (Änderung erkannt).
**Rückweg:** btnKaAlleIO löschen.

---

## CP4 – Offene Rundgänge früherer Tage auf dem Startscreen (ca. 10 Minuten)

**Nutzen:** Ein nicht abgeschlossener Rundgang von gestern oder früher geht nicht mehr verloren: unten erscheint ein roter Hinweis mit „Öffnen“ (Frage F3).

1. **scrStart → btnStartTagLaden → OnSelect** komplett ersetzen:
```
Set(varIsLoading; true);;
Concurrent(Refresh(RG_Durchfuehrungen); Refresh(RG_KategorieErgebnisse));;
Concurrent(
    ClearCollect(colDurchTag; Filter(RG_Durchfuehrungen; TagText = varTagText));
    ClearCollect(colErgTag; ShowColumns(Filter(RG_KategorieErgebnisse; TagText = varTagText); DurchfuehrungID; KategorieID));
    ClearCollect(colOffenAlt; ShowColumns(Filter(RG_Durchfuehrungen; Status = stInArbeit || Status = stAbschluss); ID; Title; RundgangID; RundgangName; TagText))
);;
Set(varIsLoading; false)
```
2. `fertig\CP4_conStartOffen.yaml` kopieren → im Baum **scrStart** markieren → Strg+V.
3. **galStartRundgaenge → Height**:
```
Parent.Height - 256 - If(conStartOffen.Visible; 96; 0)
```
(Die OnSelect-Formel von „Öffnen“ ist im Baustein; deutsch zur Kontrolle:)
```
If(!varIsLoading;
    With({o: First(Sort(Filter(colOffenAlt; DateValue(TagText) < varHeute); TagText))};
        If(!IsBlank(o);
            Set(varTag; DateValue(o.TagText));;
            Set(varTagText; o.TagText);;
            Set(varRgID; o.RundgangID);;
            Set(varSchluessel; o.Title);;
            Set(varDurchID; o.ID);;
            Navigate(scrRundgang; ScreenTransition.None)
        )
    )
)
```
**Test:** Durchführung von gestern im Status InArbeit vorhanden → Startscreen zeigt roten Hinweis → „Öffnen“ → Kategorien des alten Rundgangs, weiterarbeiten und abschließen möglich. Ohne alte offene Rundgänge: kein Hinweis, Liste volle Höhe.
**Rückweg:** conStartOffen löschen, Height zurück auf `Parent.Height - 256`, OnSelect ohne die colOffenAlt-Zeile.

---

## Nach jedem Paket
App-Überprüfung (Formeln 0) → Vorschau-Test wie oben → speichern. Wenn ich wieder einsteigen soll, sag Bescheid – ich hole mir dann den aktuellen Stand aus Studio.
