# Schritt 1 – Grundlagen für alle Pakete (ca. 5 Minuten)

Fasst CP0 + K0 + FA (Formeln/Startwerte) zusammen. Ändert sichtbar nichts an der App.

## 1a – SharePoint: Admin eintragen
IMS+ → Websiteinhalte → **RG_Konfiguration** → **+ Neu**
- Titel: `Admins`
- Wert: `josias.assefaw@technoform.com`

## 1b – App → Formulas
Studio → Strukturansicht → **App** anklicken → oben links Eigenschaft **Formulas** → in die Formelleiste klicken → **Strg+Ende** (ganz ans Ende) → **Enter** → folgenden Block einfügen:
```
fnHtml(t: Text): Text = Substitute(Substitute(Substitute(Substitute(Substitute(t; "&"; "&amp;"); "<"; "&lt;"); ">"; "&gt;"); """"; "&quot;"); "'"; "&#39;");;
cfgAdmins = Coalesce(LookUp(RG_Konfiguration; Title = "Admins").Wert; "");;
fnFehlt(typ: Text; pflicht: Boolean; bew: Text; wt: Text; wz: Number; kom: Text): Boolean = (pflicht && ((typ = "IONIO" && bew = "") || (typ = "AUSWAHL" && wt = "") || (typ = "ZAHL" && IsBlank(wz)) || (typ = "TEXT" && Trim(wt) = ""))) || (bew = "NIO" && Trim(kom) = "");;
fnDateiname(t: Text): Text = Trim(Substitute(Substitute(Substitute(Substitute(Substitute(Substitute(Substitute(Substitute(Substitute(Substitute(Substitute(Substitute(t; "\"; "-"); "/"; "-"); ":"; "-"); "*"; ""); "?"; ""); """"; ""); "<"; ""); ">"; ""); "|"; "-"); "#"; ""); "%"; ""); "'"; ""));;
fnArchivOrdner(tag: Text; test: Boolean): Text = If(test; "TEST/"; "") & Left(tag; 4) & "/" & Mid(tag; 6; 2);;
```

## 1c – App → OnStart
Eigenschaft **OnStart** → Formelleiste → **Strg+Ende**. Die letzte Zeile lautet `Set(varGeaendert; false)` → direkt dahinter `;;` tippen → **Enter** → einfügen:
```
Set(varAlleIOFrage; false);;
Set(varProtokollZeit; Now());;
Set(varIstAdmin; CountRows(Filter(Split(Lower(cfgAdmins); ";") As a; Trim(a.Value) = Lower(User().Email))) > 0);;
Set(varZuruecksetzenFrage; false);;
Set(varWeiter; false);;
Set(varZeigeFehlend; false);;
Set(varFotoPP; 0);;
Set(varArchivStart; false)
```

## 1d – Prüfen
1. Rechts oben App-Überprüfung (Stethoskop) → **Formeln: keine Fehler**.
2. Strukturansicht → **App** → „…“ → **OnStart ausführen**.
3. Links **(x) Variablen** → `varIstAdmin` muss **true** sein.
4. **Speichern** (Strg+S).

Wenn etwas rot unterstrichen ist: Screenshot an mich, ich sage dir die Korrektur.
