# TESTPROTOKOLL – Rundgangs-App (Rundgang DEV)

Alle Tests in der Studio-Vorschau (Chrome) gegen die Test-Listen auf IMSKonzept, nur Testdaten (ZZ Test, TestDatensatz = Ja). Nachlese jeweils per SharePoint-REST (nur lesen). Kennzeichnung: **belegt** = selbst gesehen/gemessen.

| Nr | Kriterium | Ablauf | Ergebnis | Status |
|---|---|---|---|---|
| T06 | R06 App.Formulas | App-Prüfung → Formeln | 0 Fehler (nach Entfernen von fnTestDoppelt) | belegt ✓ |
| T07 | R07 Planregel | Testausdruck `fnPlanPasst` über `Filter(RG_Plan, Aktiv)` für 10 Daten | 18.10 n · 19.10 J · 25.10 J · 26.10 n · 01.11 J · 02.11 J · 09.11 n · 16.11 J · 28.03.27 J · 29.03.27 n – alle wie erwartet, inkl. beider Zeitumstellungen | belegt ✓ |
| T08 | R08 SS1 Doppeltipp | Liste leer → Dreifachtipp „Starten“ | genau 1 Durchführung (ID 2, R1-2026-10-25, AnzahlKategorien 3, KategorieListe ok) | belegt ✓ |
| T09 | R09 Kategorienliste | Übersicht nach Start | Bereichsüberschriften, 1 „Als Nächstes“, Rest gesperrt (Knopf deaktiviert); Freischaltung nach jedem Speichern | belegt ✓ |
| T10 | R10 Eingabetypen | K1/K2 IONIO, K3 ZAHL (18,5 °C; 1234 h), AUSWAHL („keine Störung“), TEXT (`äöü ß "Zitat"`) | alles bedienbar, JSON korrekt (WertZahl 18.5), Rundreise beim Wiederöffnen vollständig | belegt ✓ |
| T11 | R11 Vollständigkeit | n.i.O. ohne Kommentar; Zahl 18,5 bei Soll 6–16 | „Noch offen (1): … (Kommentar)“, Speichern deaktiviert; Zahl rot „außerhalb des Sollbereichs“ + Kommentarpflicht | belegt ✓ |
| T12 | R12 SS2 Doppeltipp | Dreifachtipp „Speichern“ | genau 1 Zeile D2-K1, nächste Kategorie frei | belegt ✓ |
| T13 | R13 Restwerte | K1 ändern → Zurück („Verwerfen? Erneut tippen“) → K2 öffnen → K1 öffnen | K2 sauber, K1 zeigt gespeicherten Stand | belegt ✓ |
| T14 | R14 Konflikt | K1 offen; per REST GespeichertAm/PrueferName „ZZ Test Zweitgeraet“ gesetzt; dann Speichern | Meldung „…inzwischen von ZZ Test Zweitgeraet gespeichert…“, JSON unverändert; nach Neuöffnen Speichern ok | belegt ✓ |
| T15 | R15 SS3 | Abschluss mit 2 n.i.O.; Wiederholung (Status per REST zurück) per Doppeltipp | 2 Mängel (D1-P2, D1-P5, Wert „18,5 °C“), Status Abgeschlossen, AnzahlNIO 2; Wiederholung ohne Dubletten | belegt ✓ |
| T15b | Fehler „leere Mängelzeile“ | erster Abschluss vor Fix | „3 Mängel“, leere Zeile ID 2 (Ursache `Ungroup` mit leerer Untertabelle) → Fix, Nachtest ✓ | belegt ✓ |
| T15c | Fehler „Abfrage-Cache“ | Status per REST geändert, Übersicht neu geöffnet | alter Stand angezeigt → `Refresh` vor jedem Frisch-Lesen, Nachtest ✓ | belegt ✓ |
| T15d | SS3 neu (nach Prüf-Agent) | Abschluss mit neuem Ablauf (Abschluss zuerst, Plausibilität, Änderungsprüfung) | „2 Mängel erfasst“, REST: Abgeschlossen, keine Dubletten | belegt ✓ |
| T17 | R17 Nur Ansicht | Nach Abschluss „Ansehen“, auf i.O. tippen | Kopf „nur Ansicht“, Fuß „Nur Ansicht – …“, keine Änderung, kein Speichern | belegt ✓ |
| T18 | R18 App-Prüfung | App-Überprüfung | Formeln 0; Barrierefreiheit 57 (nur Anzeige-Labels, begründet E-07); Leistung 7 (Hilfssammlungen, begründet E-08) | belegt ✓ |
| T20 | R20 Livemonitor | Start, Fortsetzen, Öffnen, Speichern, Abschluss | Start 206+362 ms parallel · Fortsetzen 1,16 s · Öffnen 0,54–0,74 s · Speichern 2,6 s bis Übersicht · Abschluss ≈ 4,1 s (10 Aufrufe) | belegt ✓ |
| T-Hoch | Design Hochformat | Vorschau „Canvas-Größe“ | Start, Übersicht, Kategorie sauber; keine Überlappungen | belegt ✓ |

Offen: R16 (SS4-Mail, braucht Freigabe – FRAGEN_AN_JOSIAS F1), R21 (Testdaten am Ende löschen), J1–J3 (Josias/Fachbereich).
