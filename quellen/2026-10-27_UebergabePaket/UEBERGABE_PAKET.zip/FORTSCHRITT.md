# FORTSCHRITT – Rundgangs-App

Oben der aktuelle Stand, darunter das Protokoll (vorher/nachher/Rückweg). Nach einer Kontext-Zusammenfassung zuerst: Aktueller Stand → `AUFTRAG_RUNDGANG.md` → `FEATURES.json`.

## Aktueller Stand (25.10.2026 ~23:50)
**App-Kern fertig und geprüft:** R01–R15, R17–R20 bestanden (FEATURES.json, Belege in TESTPROTOKOLL.md). Prüf-Agent-Befunde eingearbeitet (ENTSCHEIDUNGEN.md). App-Prüfung: 0 Formelfehler. YAML = Studio-Export (0 Unterschiede). App gespeichert, nicht veröffentlicht, nicht geteilt.

**Offen:** R16 SS4-Mail (wartet auf Freigabe F1), R21 Testdaten löschen (am Ende; aktuell D2 + D2-K1), R22 Vault-Index, J1–J3 (Josias/Fachbereich). Fragen: FRAGEN_AN_JOSIAS.md.

**Achtung Studio-Bedienung:** Vor Studio-Eingaben immer prüfen, dass die Vorschau beendet ist (sonst landen Klicks in der laufenden App – am 25.10. einmal passiert, ohne Folgen).

**Werkzeuge Studio ↔ Datei:** `bau/werkzeuge/formel_ablage.js` (YAML-Eigenschaft → deutsche Formel → `app/ablage/…txt`) + `ablage_server.js` (Port 8765: `/<datei>` mit KOPIEREN-Knopf; **`/empfang`**: Strg+V speichert den Text als `app/ablage/empfang_*.txt`). Damit: Studio-Formel per Strg+A/Strg+C sichern, mit Datei vergleichen (`git diff --no-index -w`), neue Fassung einfügen, zurücklesen.

## Protokoll

### 25.10.2026 – Vorbereitung
- Konzept, Entscheidungen, Prüfungen: Vault `Rundgang/01_Planung_2026-10-25/`.
- Schema + Generator + Konsolen-Skript (`bau/`), Nachbau-Tests 33/33, unabhängige Prüfung (8 Befunde, eingearbeitet).
- ReklasTest2: Trockenlauf, ANLEGEN 139, Rückgabe OK (Logs in `bau/eingang/`).
- IMSKonzept: Vorab-Check (Sprache 1033, 20 fremde Listen → Schutzliste), ANLEGEN Fassung `b44bde9d74f71ed7`: FERTIG 139, keine Warnung.
- Rückweg Listen: Listen tragen Marke `ZZ_RG_P0` in der Beschreibung; Entfernen nur durch Josias.

### 25.10.2026 ~19:40 – R01 Rückgabe IMSKonzept + Navigation bereinigt (Chrome, selbst ausgeführt)
- Rückgabe per Konsole (nur lesen): `bau/eingang/rg_rueckgabe_IMSKonzept_2026-10-25T18-38-22-082Z.json`; `pruefe_rg_rueckgabe.js` → **OK – Stand entspricht dem Schema (9 Listen)**, StartMontag = 19.10. 00:00 Berlin. **R01 bestanden.**
- Befund: SharePoint hat alle 9 neuen Listen automatisch unter „Zuletzt verwendet“ (Knoten 1033) in die linke Navigation gesetzt (sichtbar für alle IMS+-Nutzer), obwohl `OnQuickLaunch = false`. Zeigt nur 5 auf einmal.
- Vorher: Kinder von 1033 = Knoten 2040–2048 (RG_Rundgaenge … RG_Maengel), sonst keine.
- Aktion: Knoten 2040–2048 per REST `GetNodeById(id)` DELETE, je Knoten vorher geprüft: Titel beginnt mit `RG_` und URL `/Lists/RG_…`. Alle HTTP 200.
- Nachher: Navigation „Start[] · Hilfe und Tutorials[] · Zuletzt verwendet[]“. Listen selbst unverändert.
- Rückweg: Knoten neu anlegen über Websiteeinstellungen → Navigation, oder REST `navigation/quicklaunch` (Titel/URL siehe oben).
- Lehre (auch für Reklas auf IMS+): Das Anlegeskript sollte „Zuletzt verwendet“-Knoten der eigenen Listen nach dem Anlegen entfernen. ReklasTest2 hat vermutlich dasselbe (Test-Site, nicht bereinigt).

### 25.10.2026 ~19:40–20:05 – R02–R05 App angelegt, eingestellt, Datenquellen, Vorab-Tests (Chrome, selbst)
- **R02** Vorher: keine App. Nachher: `Rundgang DEV`, App-ID `1b9800f7-8289-4ee8-b720-cef0bbf1eae1`, Umgebung Personal Productivity (Default-84e2e900…), angelegt über `canvas/?action=new-blank&form-factor=tablet`, gespeichert 19:40:49 („Vorhandene ersetzen“ nicht angefasst). Beschreibung „ENTWICKLUNG – … Nicht produktiv, nicht teilen“. Rückweg: App im Portal löschen (nur Josias).
- **R03** Einstellungen (Studio 3.26102.13): Datenzeilen-Grenzwert 500 → **2000**; Ausrichtung Querformat → **Hochformat**; App-Layout Fest → **Dynamisch** (Ausrichtungssperre damit ausgegraut, HAN-01); OnStart-Eigenschaft an; Offline (nur Dataverse) aus; Updates „Neu“: Benutzerdefinierte Typen **an** (ParseJSON/IsType/AsType), Erweiterte Komponenteneigenschaften an, Verzögertes Laden mit StartScreen an, Erweiterte Medienunterstützung SaveData an, Copilot-Formeln aus Kommentaren an. Studio deutsch, Laufzeit `Language()` = de-DE.
- **R04** 9 Datenquellen `RG_Bereiche … RG_Rundgaenge` per SharePoint-Verbindung (Josias) zur URL IMSKonzept (Liste auf „RG_“ gefiltert, nur diese 9 angehakt). Konnektorstufen in der Studio-Auswahl: **SharePoint, Office 365 Outlook, Office 365-Benutzer, Office 365-Gruppen ohne Premium-Raute = Standard** (Premium z. B. airSlate, Aquaforest mit Raute). Outlook/Benutzer noch nicht hinzugefügt.
- **R05** Test-Steuerelemente per YAML (`app/yaml/r05_vorabtests.yaml`, Zwischenablage → Screen1), App.Formulas `fnTestDoppelt(x: Number): Number = x * 2`. Vorschau (Browser 1706×656):
  - UDF: `42` ✓
  - JSON: `[{"a":1,"b":"x","c":13.2}]` – **Dezimalpunkt, gültiges JSON** ✓; ParseJSON-Rundreise `c=13,2` ✓; `ParseJSON(...).z` = 5 ✓
  - DateDiff 04.01.→05.04.2027 Days = **91** (über Zeitumstellung korrekt), 19.→26.10. = 7, Stunden/24 = 91 ✓
  - `First(RG_Plan).StartMontag` = **2026-10-19 00:00** ✓
  - Zahleingabe (Format Zahl): „13,2“ → 13,2 ✓; „19.653“ → 19653 (Tausenderpunkt akzeptiert, kein Fehler wie in MoreApp) ✓; „abc“ wird nicht angenommen ✓. Tablet-Tastatur offen (J1).
- YAML-Format belegt durch Kopie aus Studio: `Label@2.5.1`, `Classic/TextInput@2.3.2`, `Classic/Button@2.2.0`, invariante Schreibweise (Kommas, Punkt-Dezimal); Einfügen per Zwischenablage auf markiertem Screen funktioniert.

### 25.10.2026 ~20:05–22:30 – R06 App.Formulas/OnStart, drei Screens per YAML (Chrome, selbst)
- App.Formulas (`app/formeln/App.Formulas.pfx`, in Studio deutsch eingetippt) und App.OnStart (`App.OnStart.pfx`) gesetzt, keine Formelfehler. StartScreen = scrStart. **R06 bestanden.**
- scrStart, scrRundgang, scrKategorie aus `app/yaml/*.yaml` per Zwischenablage eingefügt. Laufzeitkorrekturen: `SortByColumns` → `Sort` (Bezeichner abgelehnt), Balkenbreite `ThisItem.Gesamt > 0` (Teilung durch 0).
- **Befund (belegt):** Beim YAML-Einfügen in Galerien mit flexibler Höhe friert Studio Y-Formeln von Kindelementen teilweise zu Zahlen ein (conRuKarte.Y, lblRuAbstand.Y, txtKaKommentar.Y = 98); Höhenformeln bleiben. Studio-Zeichenfläche berechnet flexible Höhen nicht neu – nur die Vorschau zeigt den echten Stand.

### 25.10.2026 ~22:30–23:10 – Y-Formeln, Ende-zu-Ende-Test, zwei Fehler behoben (Chrome, selbst)
- Y-Formeln per Formelleiste gesetzt: conRuKarte.Y `If(ThisItem.ErsteImBereich; 44; 0) + 8`, lblRuAbstand.Y `… + 100`, txtKaKommentar.Y `54 + If(ThisItem.Hinweis <> ""; 24; 0) + 68`. Übrige Kartenelemente per Code-Ansicht geprüft: Formeln intakt (`app/ablage/studio_galKaPruefpunkte_2026-10-25.yaml`). Debug-Anhang aus lblRuKatName.Text entfernt. YAML nachgezogen.
- Versehen: lblRuAbstand.X kurz mit der Y-Formel belegt (falscher Listeneintrag), sofort auf 0 zurückgesetzt. Eigenschaftsauswahl jetzt per Tippen + Enter statt Klick.
- **Vorschau-Test D1 (R1-2026-10-25):**
  - K1: i.O. + n.i.O. → Kommentarfeld erscheint, „Noch offen (1): … (Kommentar)“, Speichern gesperrt; mit Kommentar gespeichert → „Gespeichert.“, K1 „Erledigt · 1 n.i.O.“, K2 freigeschaltet, K3 gesperrt. ✓
  - K2: 2× i.O. gespeichert → K3 frei. ✓
  - K3: ZAHL „18,5“ (Soll 6–16) → rot „außerhalb des Sollbereichs“ + Kommentarpflicht ✓; ZAHL 1234 h ✓; AUSWAHL „keine Störung“ ✓; TEXT mit `äöü ß "Zitat"` ✓. Gespeichert.
  - „Bearbeiten“ K3: alle Werte inkl. 18,5 und Kommentar aus JSON vorbelegt ✓.
  - REST-Nachlese RG_KategorieErgebnisse: D1-K1/K2/K3 je eine Zeile, JSON korrekt (WertZahl 18.5, Umlaute/Anführungszeichen erhalten).
- **Fehler 1 (belegt):** Abschluss meldete „3 Mängel“ bei 2 n.i.O.; RG_Maengel hatte eine leere Zeile (ID 2). Ursache: `Ungroup` erzeugt für eine Kategorie ohne n.i.O. (leere Untertabelle) eine Leerzeile. Fix in btnRuAbschluss.OnSelect: `ForAll(Filter(colErgAlle, AnzahlNIO > 0) As e3, …)` und `Filter(Ungroup(…), !IsBlank(PruefpunktID))`.
- **Fehler 2 (belegt):** Nach Zurücksetzen per REST zeigte scrRundgang weiter „Abgeschlossen · 3 Mängel“, obwohl SharePoint „InArbeit“ hatte und scrStart (anderer Filter) es richtig zeigte → Power Apps liefert identische Abfragen aus dem Sitzungs-Cache. Betrifft auch die Konfliktprüfung SS2 (zweites Gerät). Fix: `Refresh(...)` vor jedem Frisch-Lesen: scrRundgang.OnVisible, scrKategorie.OnVisible, btnRgAktion (SS1), btnKaSpeichern (SS2), btnRuAbschluss (SS3), btnStartTagLaden.
- Übertragung je Formel: Studio-Fassung gesichert (`app/ablage/vorher_f1…f6.txt`, `studio_btnRuAbschluss_vorher.txt`), Vergleich mit Datei → einzige Abweichung jeweils die beabsichtigte Zeile, dann eingefügt; btnRuAbschluss zurückgelesen = Datei.
- Testdaten-Rücksetzung D1 (eigene, TestDatensatz = Ja): RG_Maengel ID 1, 2, 3 gelöscht (Papierkorb), D1 Status → InArbeit, EndeZeit/AnzahlNIO leer. Nachtest: „Rundgang abgeschlossen · 2 Mängel erfasst.“, REST: D1 Abgeschlossen, AnzahlNIO 2, RG_Maengel ID 4 (D1-P2) und 5 (D1-P5, Wert „18,5 °C“), keine Leerzeile. **R15 bestanden** (Wiederholung ohne Dubletten noch gezielt zu testen).
- Bestehende eigene Testdaten jetzt: RG_Durchfuehrungen 1, RG_KategorieErgebnisse 1–3, RG_Maengel 4–5.
- Rückweg Formeln: `app/ablage/vorher_*.txt` in die jeweilige Eigenschaft einfügen.

### 25.10.2026 ~23:10–23:50 – Tests R07/R13/R14/R17, Aufräumen, App-Prüfung, Prüf-Agent, Livemonitor (Chrome, selbst)
- R13/R14/R17 getestet (TESTPROTOKOLL T13/T14/T17). R14 mit simuliertem Zweitgerät: per REST D1-K1 GespeichertAm/PrueferName geändert (eigene Testzeile).
- R07: Testausdruck auf Screen1-Label, 10 Daten korrekt (T07).
- Screen1 (Testelemente) gelöscht; Sicherung `app/yaml/screen1_sicherung_vor_loeschen_2026-10-25.yaml`. fnTestDoppelt aus App.Formulas entfernt (Vorher: `app/ablage/vorher_App.Formulas.txt`).
- App-Prüfung: 8 AccessibleLabel ergänzt, `AllItemsCount`, varMeldung/varStartFertig aus OnStart entfernt, varPatchFehler in Fehlermeldungen. Rest begründet (E-07, E-08).
- Prüf-Agent (R19): 10 Befunde; 1–4, 6, 7 umgesetzt (SS3 neu: Abschluss zuerst + Nachlese, Plausibilität, Änderungsprüfung; Refresh vor Nachlesen; SS2 parallel lesen + leere Kategorie; Zahl neu bewerten). Erster Einfügeversuch: 2 Formelfehler durch `IfError`-Typmischung → E-03, behoben, App-Prüfung 0.
- Versehen: Studio war noch in der Vorschau, als die erste Einfügerunde lief – Klicks lagen außerhalb der App-Fläche, nur Textmarkierung, keine Daten geändert. Danach Vorschau beendet und wiederholt.
- Livemonitor (R20) vor/nach Änderungen gemessen (T20). Monitordaten einmal geleert (nur Anzeige).
- Testdaten: D1 inkl. K1–K3 und Mängel 4/5 in den Papierkorb (recycle, nur TestDatensatz = Ja, Präfix D1-/R1-2026-10-25). Danach R08/R12: D2 (ID 2) und D2-K1 (ID 4) neu angelegt – **bestehen noch**.
- YAML erneut aus Studio exportiert: 0 Unterschiede.
- Rückweg: Formeln aus `app/ablage/vorher_*`/git-Historie; Papierkorb der IMS+-Site für gelöschte Testzeilen.

### 26.10.2026 – Protokoll-Screen begonnen, dann auf Wunsch gestoppt
- Studio war über Nacht neu geladen (neues Layout) und stand in der Vorschau; Klicks trafen nur Text/Kopf, nichts ausgelöst.
- HTML-Text-Steuerelement testweise in scrStart eingefügt (um den YAML-Typ zu lesen) und sofort wieder gelöscht. App = gespeicherter Stand vom 25.10.
- Josias hat das Bauziel gestoppt (Frage: Umstellung auf manuellen Umbau). Protokoll-Screen (HTML-Protokoll als Vorlage für SS4) nicht gebaut.
- R21: D2 (ID 2) und D2-K1 (ID 4) in den Papierkorb; Nachlese: Durchfuehrungen/Ergebnisse/Maengel je 0 Zeilen. Stammdaten (ZZ Test) bleiben fuer den Tablet-Test.

### 26.10.2026 – Umstellung auf manuellen Umbau (Entscheidung Josias)
- Josias baut ab jetzt manuell in Studio weiter. Claude ändert die App nicht mehr ohne neuen Auftrag.
- Stand bei Übergabe: R01–R15, R17–R22 belegt; offen R16 (Protokoll-Mail, Freigabe nötig), Veröffentlichen, J1–J3.
- Achtung bei Wiedereinstieg: app/yaml ist NICHT mehr automatisch aktuell – zuerst Screens per Ansichtscode aus Studio exportieren und mit vergleiche_yaml.js abgleichen.
- Versehen: Vault-Werkzeug search_and_replace liest das Muster als regulaeren Ausdruck; das '|' im Tabellentext passte ueberall und hat Rundgang/00_INDEX_Rundgang.md zerschossen (500 Einfuegungen). Sofort aus meinem eigenen Stand vom 25.10. komplett neu geschrieben (2364 Byte, 4 Ueberschriften geprueft). Lehre: Muster mit | ( ) . * escapen oder Datei komplett neu schreiben.

### 26.10.2026 – Code- und Ideen-Pakete fuer den manuellen Weiterbau
- Ordner pakete\: CODE_PAKETE.md (CP0 Vorbereitung, CP1 Protokoll-Screen, CP2 Protokoll-Mail nach Freigabe, CP3 Schnellknopf Offene auf i.O., CP4 offene Rundgaenge frueherer Tage), fertig\*.yaml zum Einfuegen, formeln\ (Datei-Schreibweise) + formeln\de\ (deutsch). Erzeugt mit pakete\baue_pakete.js (Klammerbilanz ok, alle Platzhalter gefuellt). IDEEN_PAKETE.md mit 16 Ideen (A/B/C) und Empfehlung. App selbst NICHT veraendert; Pakete in Studio noch nicht getestet.
- Paket FA (Fotos bei Maengeln + PDF-Archiv): pakete\FOTO_ARCHIV_PAKET.md, YAML fertig\FA_*.yaml, Formeln formeln\fa_* (SS3-Fassung per fa_ss3_bauen.js aus aktueller YAML abgeleitet). 2 Bibliotheken, 3 Spalten, 2 Flows (Power Apps V2, nur Standard-Bausteine), App-Aenderungen. Annahmen (PDF, IMS+-Bibliotheken, Rechte erben, nur n.i.O.) im Paket markiert. Nichts davon eingebaut oder getestet; formel_ablage.js um Ausgabe 'inv' erweitert.
- Paket K (Punkte 2, 3, 7, 8, 9): pakete\PAKET_K_KERN.md, fertig\K_*.yaml, formeln\k_* ; k_ableiten.js leitet scrRundgang.OnVisible aus der aktuellen YAML ab und baut die FA-Formeln (OnVisible, SS2) neu auf K-Basis. Reihenfolge jetzt CP0 -> CP1 -> K -> (CP3, CP4) -> FA -> CP2. Nicht eingebaut/getestet.
- 26.10.: Pakete selbst geprueft (CP3 nach K, lblKaStand) und durch zweiten Pruef-Agenten (11 Befunde, 10 behoben, 1 bewusst belassen -> ENTSCHEIDUNGEN.md). pruefe_namen.js: 110 Namen, alle definiert. Gesamtreihenfolge CP0 -> CP1 -> K -> CP3 -> CP4 -> FA -> CP2.

### 26.10.2026 abends - Manueller Einbau durch Josias (Anleitung Schritt fuer Schritt im Chat)
- Josias hat eingebaut: Schritt 1 (Grundlagen: Formulas/OnStart, ohne varSprungRec-Vorbelegung), CP1 (scrProtokoll, htmProtokoll, btnRuProtokoll; Protokoll getestet), Paket K (Kategorie-OnVisible, Items/Default, Fehlend-Labels, Fortschritt, Karten-Rahmen, Balken, Statuszeile, Speichern-Knopf, scrRundgang.OnVisible, tmrWeiter, btnRuZuruecksetzen). App-Pruefung: Formeln 0 Fehler. Noch NICHT getestet: Paket K im Ablauf.
- Lehren: Navigate in OnVisible nicht erlaubt (Zeitgeber tmrWeiter); Classic/Button kennt AccessibleLabel nicht (YAML); YAML-Zeilen mit '{n: ...' brauchen Block-Schreibweise |-; Alias R in PowerShell = Invoke-History.
- Testdaten (D3: Durchfuehrung 3, Ergebnisse 5-7, Mangel 6 - Josias' Testrundgang) auf seinen Wunsch-Zweck (frischer Test von Paket K) in den Papierkorb; Nachlese: alle drei Listen 0 Zeilen.
- CP3 (btnKaAlleIO) von Josias abgelehnt (E-09), Knopf in Studio zu entfernen; Paket K komplett getestet (Speichern & weiter, Abschluss ok). Auffaellig: Testdurchlauf D5 hatte keinen Mangel in RG_Maengel obwohl ein n.i.O. erwartet war - Nachtest steht aus (Banner-Zahl abgefragt).

### 26.10.2026 nachmittags - Claude baut wieder selbst in Chrome weiter (Goal), Studio-Bearbeitung von Josias freigegeben
- Sicherung vor dem Weiterbau: app\yaml\stand_2026-10-26_vor_Chrome\ (scrStart, scrKategorie, scrRundgang, scrProtokoll) = App-Stand mit Schritt 1, CP1, K, CP4 (ohne CP3).
- Tests in der Vorschau (Chrome): Tag-Fix CP4 ok (Tagesfeld zeigt Samstag 24.10.); Galerie zeigte am Samstag keine Karte (Plan passt nicht) -> galStartRundgaenge.Items um `|| !IsBlank(LookUp(colDurchTag ...))` erweitert (Datei app\ablage\gal_items_neu.txt), Formeln 0 Fehler, gespeichert.
- Mangel-Test bestanden: Abschluss meldet 1 Mangel, RG_Maengel D8-P2 (Kommentar 'klima tropft', Status Offen); Protokoll zeigt alles korrekt. Der frueher fehlende Mangel war vermutlich ein Testdurchlauf ohne n.i.O.
- Josias hat im Banner (lblRuBanner) den Hinweis 'Support: Josias.Assefaw@technoform.com' ergaenzt.
- Testdaten (D8, D9) nach dem Test in den Papierkorb, Listen 0 Zeilen.
- VORFALL Vault: mein search_and_replace-Aufruf (Muster mit fuehrendem '|') hat am 26.10. 07:44 UTC viele Vault-Dateien beschaedigt (Regex-Leertreffer). Josias stellt wieder her. Ich schreibe nicht mehr in den Vault. Lehre: search_and_replace nur mit escaptem Muster und `scope`, vorher dry_run, Ergebnis ueber ALLE Dateien pruefen.

## 26.10.2026 (Chrome) – Flow 1 RG_Foto_hochladen gebaut
- Power Automate (Flow-ID 3c8c1241-13eb-4769-9e72-98a8e06c588c): Trigger "Power Apps V2" (Foto, Dateiname, Ordner, DurchfuehrungID, PruefpunktID, Test) -> SharePoint "Create file" (IMS+, /RG_Fotos/<Ordner>/<Dateiname>) -> "Update file properties" (DurchfuehrungID, PruefpunktID, TestDatensatz).
- Bewusst KEINE "Response"-Aktion: sie ist ein Premium-Connector (HTTP). Die App baut die Datei-URL selbst: Site + /RG_Fotos/ + Ordner + / + Dateiname.
- Nicht angefasst: Josias' bestehende Flows. Noch nicht getestet, noch nicht in der App eingebunden.
- Naechste Schritte: Flow 2 RG_Protokoll_archivieren, Flows in App einbinden, FA-Formeln anpassen (kein .url aus Flow).
- Flow 1 korrigiert: Schraegstrich zwischen /RG_Fotos/ und Ordner fehlte (Tippen von "/" oeffnet das Dynamic-Content-Menue und wird verschluckt -> "//" tippen). Gespeichert.
- Flow 2 RG_Protokoll_archivieren gebaut (Flow-ID c6ac2276-0b3e-465e-9239-42c84883bba4): Trigger (HTML, Dateiname, Ordner, DurchfuehrungID, Test) -> OneDrive "Create file" /RG_Temp/<Dateiname>.html (<meta charset=utf-8> + HTML) -> OneDrive "Convert file" (PDF) -> SharePoint "Create file" /RG_Protokolle/<Ordner>/<Dateiname> -> "Update file properties" (DurchfuehrungID, TestDatensatz). Ohne Response (Premium). Temp-Datei in OneDrive /RG_Temp wird noch NICHT geloescht (offen: Delete-file-Schritt).
- Trigger-Schluessel: Flow 1 text=Dateiname, text_1=Ordner; Flow 2 text=HTML, text_1=Dateiname, text_2=Ordner. Die App uebergibt positionsgleich zur Eingabereihenfolge.
- App (Studio): beide Flows eingebunden; Daten RG_Durchfuehrungen/RG_Maengel aktualisiert; App.Formulas + fnSpUrl(bib; pfad) (baut die SharePoint-URL selbst, da Flows keine Antwort liefern); scrProtokoll: btnPrArchivieren + tmrPrArchiv (YAML app/ablage/fa_Archiv_neu.yaml, ohne .url-Auswertung, Erfolg = !IsError(Run(...))), htmProtokoll.HtmlText (CP1 + Archiv-Link, Foto-Links als Text "Foto >"), scrProtokoll.OnVisible (Auto-Archiv per Timer), btnRuProtokoll.Text. App-Check Formeln 0, Datenquelle nur Warnung "ungenutzter Flow RG_Foto_hochladen". Gespeichert 26.10.2026 16:35.
- OFFEN/Test: Archiv-PDF-Lauf im Vorschau-Modus; Foto-Teil (Paket FA Schritte 3-7: scrKategorie OnVisible/Speichern/btnKaFoto/conKaFoto/AddMedia) noch nicht eingebaut.
- TEST 26.10. (Vorschau, Test-Rundgang D10): 3 Kategorien gespeichert (1 Mangel), Abschluss, Protokoll oeffnen -> "Protokoll als PDF archiviert" nach <5 s. PDF liegt in RG_Protokolle/TEST/2026/10/R1-2026-10-25 ZZ Test Objektrundgang TCC 20261026-163818.pdf (45 KB, DurchfuehrungID=10, TestDatensatz=Ja), Inhalt korrekt (Kategorien, n.i.O. rot, Kommentar, Zahlenwerte, TESTDATEN-Vermerk). Schwaeche: Hintergrundfarben werden im PDF nicht gedruckt (weisser Kopftext auf weiss) -> btnPrArchivieren ersetzt vor dem Senden den Kopf-Stil per Substitute durch blaue Schrift + Linie (nicht erneut getestet).
- Beobachtung: der Flow-Aufruf ohne Response kehrt zurueck, bevor die App-Meldung erscheint; das PDF war danach vorhanden. Risiko: schlaegt der Flow spaeter fehl, steht trotzdem ein Link in ProtokollUrl. Pruefen im Flow-Verlauf (Power Automate) oder Bibliothek.
- Beobachtung: der aktuelle btnRuAbschluss bleibt nach dem Abschluss auf der Uebersicht (springt nicht zum Protokoll); das kommt erst mit Paket-FA-Schritt 8. Protokoll ist ueber "Protokoll ⚠ >" erreichbar und archiviert dort automatisch.
- 26.10. Reset auf Wunsch von Josias: Testdaten D10 (RG_Durchfuehrungen 10, RG_KategorieErgebnisse 17-19, RG_Maengel 8) sowie Test-PDF und Ordner RG_Protokolle/TEST in den Papierkorb verschoben (wiederherstellbar). Alle Listen jetzt ohne Testdaten; RG_Fotos leer.
- 26.10. Foto-Test im Rundgang (Wunsch Josias: "so etwas wie Thermometer-Foto"): RG_Pruefpunkte neue Spalte FotoMoeglich (Ja/Nein, Standard Nein); neuer Test-Prüfpunkt Id 10 "ZZ Test Thermometer Serverraum (Foto der Anzeige)" in Kategorie 1, Reihenfolge 3, IONIO, Pflicht, FotoMoeglich=Ja. Bis die App den Foto-Knopf kennt, verhält er sich wie ein normaler i.O./n.i.O.-Punkt. Geplant: Foto-Knopf in der Karte sichtbar wenn Bewertung n.i.O. ODER FotoMoeglich; colAntworten bekommt Feld FotoMoeglich.
- Verworfen: eigener Foto-Test-Bildschirm (Josias will den Test im echten Rundgang).
- 26.10. Foto-Teil in der App eingebaut (Studio, gespeichert): addKaFoto (Bild hinzufuegen, OnChange sammelt in colFotos) in conKaFotoKarte, conKaFoto (Foto-Fenster, YAML), imgKaFotoNeu in galKaFotoNeu, btnKaFoto in der Karte (sichtbar bei n.i.O. ODER FotoMoeglich), scrKategorie.OnVisible (FotoMoeglich im colAntworten), btnKaSpeichern.OnSelect (Foto-Upload per aRG_Foto_hochladen.Run, Link = fnSpUrl; Fehler "x" in Concat behoben), btnRuAbschluss.OnSelect (FotoUrls an Maengel, danach Sprung zum Protokoll), txtKaKommentar.Width = Parent.Width-196. App-Check Formeln 0.
- Wichtig: In Studio heisst der Flow "aRG_Foto_hochladen" (alter Name mit "a" beim Hinzufuegen). Formeln nutzen diesen Namen.
- NOCH NICHT GETESTET: Foto aufnehmen/auswaehlen, Upload, Foto-Fenster (Z-Reihenfolge ✕-Knopf vs. Bild unklar), Y des Foto-Knopfs in der Karte (Soll 54 + If(Hinweis<>"";24;0) + 68), Thermometer-Testpunkt (Kategorie 1, FotoMoeglich=Ja). Test: Rundgang starten, Kategorie 1, beim Thermometer-Punkt Foto-Knopf antippen.
- 27.10. Fehler behoben: Foto-Knopf bei Punkten mit FotoMoeglich=Ja fehlte. Ursache: colAntworten.FotoMoeglich kam nicht an (Wert leer); Karte war zu niedrig und Knopf-Y eingefroren (98). Fix: Kartenhoehe, Knopf-Y und Sichtbarkeit sowie die Upload-Bedingung in btnKaSpeichern lesen FotoMoeglich direkt per LookUp(colPP; ID = PruefpunktID).FotoMoeglich. Y des Knopfs: 54 + Hinweis(24) + If(NIO; 68; 56). Kartenhoehe: 54 + Hinweis + 56 + If(NIO; 68; If(Foto; 64; 0)) + 20.
- 27.10. Veroeffentlicht 08:06 (DEV-App fuer alle mit Zugriff). Der normale Abspiel-Link zeigt jetzt Foto-Teil und PDF-Archiv.
- Foto-Upload selbst NICHT getestet: Datei-Dialog der Vorschau (fremder Frame) ist fuer die Automation nicht bedienbar. Foto-Fenster oeffnet sich; Knopf "Foto aufnehmen / auswaehlen" erscheint mit sehr grosser Schrift (Optik offen).
- Testdaten stehen noch: RG_Plan "ZZ Test Di jede Woche (Foto-Test)", Durchfuehrung D13 (in Arbeit). Hilfsserver ablage_server.js laeuft wieder.
- 27.10. Fehler behoben (Meldung Josias): Kommentar blieb im Protokoll stehen, wenn man nach n.i.O. + Kommentar wieder auf i.O. wechselte. Fix in btnKaSpeichern.OnSelect: vor dem JSON-Aufbau `UpdateIf(colAntworten; Bewertung <> "NIO"; {Kommentar: ""})`. Wirkt nur fuer kuenftig gespeicherte Kategorien; bereits gespeicherte Antworten behalten ihren Kommentar. Hinweis fuer die Funktion "Pflicht-Kommentar auch bei i.O.": diese Zeile muss dann pro Punkt abhaengig gemacht werden. Veroeffentlicht 27.10. ca. 08:44.
- Lehre: Zwischenablage-Kopie immer pruefen (Seite zeigt "KOPIERT <Laenge>", Laenge muss zur Datei passen), sonst fuegt Studio alten Inhalt ein (35 Formelfehler).
