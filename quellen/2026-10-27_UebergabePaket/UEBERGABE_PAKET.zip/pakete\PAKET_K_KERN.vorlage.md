# Paket K – Kern-Verbesserungen (Punkte 2, 3, 7, 8, 9)

Stand 26.10.2026 · passend zum App-Stand vom 25.10. **Voraussetzung: CP0 aus `CODE_PAKETE.md`.** Empfohlene Reihenfolge insgesamt: **CP0 → CP1 → K → (CP3, CP4) → FA → CP2**. Paket FA baut ab jetzt auf K auf (seine Formeln enthalten K schon).

| Nr | Was | Wo |
|---|---|---|
| **2** | Admin-Ausweg: hängt ein Abschluss („Abschluss begonnen, aber nicht beendet“), setzt ein Admin den Rundgang mit zweitem Tippen auf „In Arbeit“ zurück; vorläufige Mängel werden dabei entfernt und beim nächsten Abschluss neu erzeugt | scrRundgang, Kopf rechts |
| **3** | Nur-Ansicht zeigt **genau das Gespeicherte** (aus dem JSON), auch wenn Prüfpunkte inzwischen geändert/deaktiviert sind. Beim Bearbeiten bleiben Antworten deaktivierter Prüfpunkte erhalten (ausgeblendet) | scrKategorie.OnVisible |
| **7** | **„Speichern & weiter“**: nach dem Speichern öffnet sich direkt die nächste offene Kategorie. Sind alle erledigt → Übersicht mit Abschluss | btnKaSpeichern, scrRundgang.OnVisible |
| **8** | Prüfpunktliste beginnt beim Öffnen **immer oben** | scrKategorie |
| **9** | **Fortschritt** im Kopf („5 von 8 ausgefüllt“) + Balken; ist noch etwas offen, wird der Speichern-Knopf zu **„Offene Punkte ↓“**: springt zum ersten offenen Punkt und rahmt alle offenen Karten rot | scrKategorie |

**Einfügen wie gehabt:** YAML aus `pakete\fertig\` (Editor → Strg+A/C → Ziel im Baum markieren → Strg+V), Formeln in der Formelleiste in der hier abgedruckten deutschen Fassung. Vorher Vorschau beenden, nachher App-Überprüfung (Formeln 0) und speichern.

---

## K0 – Vorbereitung

**SharePoint, Liste RG_Konfiguration:** neue Zeile · Titel `Admins` · Wert: E-Mail-Adressen der Admins, getrennt mit `;` (z. B. deine Adresse).

**App → Formulas** – ans Ende anhängen:
```
{{de:k_App_Formulas_Zusatz}}
```
**App → OnStart** – ans Ende anhängen (vorher `;;` an die letzte Zeile):
```
{{de:k_OnStart_Zusatz}}
```
Danach „OnStart ausführen“.

---

## K1 – Kategorie-Screen (Punkte 3, 8, 9)

1. **scrKategorie → OnVisible** komplett ersetzen:
```
{{de:k_kat_OnVisible}}
```
2. **galKaPruefpunkte → Items:**
```
{{de:k_gal_Items}}
```
3. **galKaPruefpunkte → Default:**
```
{{de:k_gal_Default}}
```
4. **lblKaFehlendAnzahl → Text:**
```
{{de:k_lblKaFehlendAnzahl_Text}}
```
5. **lblKaFehlend → Text:**
```
{{de:k_lblKaFehlend_Text}}
```
6. **lblKaUnter → Text** (Fortschritt im Kopf):
```
{{de:k_lblKaUnter_Text}}
```
7. **conKaKarte → BorderColor:**
```
{{de:k_karte_BorderColor}}
```
   **conKaKarte → BorderThickness:**
```
{{de:k_karte_BorderThickness}}
```
8. **Fortschrittsbalken:** `fertig\K_conKaBalken.yaml` → **scrKategorie** markieren → Strg+V (liegt direkt unter dem blauen Kopf, Y 136).
9. **lblKaStand → Text** (zählt ausgeblendete Antworten nicht mit):
```
{{de:k_lblKaStand_Text}}
```

## K2 – Speichern-Knopf (Punkte 7, 9)

**btnKaSpeichern:**
- **OnSelect** komplett ersetzen:
```
{{de:k_ss2}}
```
- **Text:**
```
{{de:k_btnKaSpeichern_Text}}
```
- **Fill:**
```
{{de:k_btnKaSpeichern_Fill}}
```
- **Color:**
```
{{de:k_btnKaSpeichern_Color}}
```
- **DisplayMode:**
```
{{de:k_btnKaSpeichern_DisplayMode}}
```

## K3 – Übersicht (Punkte 2, 7)

1. **scrRundgang → OnVisible** komplett ersetzen:
```
{{de:k_ru_OnVisible}}
```
2. **Admin-Knopf:** `fertig\K_btnRuZuruecksetzen.yaml` → **conRuKopf** markieren → Strg+V. Formel zur Kontrolle:
```
{{de:k_btnRuZuruecksetzen}}
```

---

## K4 – Test
1. **9 + 8:** Kategorie mit 3 Pflichtpunkten öffnen → Kopf „0 von 3 ausgefüllt“, Balken leer, Knopf „Offene Punkte ↓“ (hellblau). Nach unten scrollen, zurück, andere Kategorie öffnen → Liste beginnt oben. Einen Punkt ausfüllen → „1 von 3“. „Offene Punkte ↓“ tippen → springt zum ersten offenen, offene Karten rot umrandet. Alle ausfüllen → Balken grün, Knopf „Speichern & weiter“.
2. **7:** „Speichern & weiter“ → kurz Übersicht → nächste Kategorie öffnet sich automatisch. Letzte Kategorie → Knopf heißt „Speichern“ → bleibt in der Übersicht.
3. **3:** Rundgang abschließen → Kategorie „Ansehen“ → zeigt die gespeicherten Werte. Dann in SharePoint einen Prüfpunkt dieser Kategorie auf Aktiv = Nein → „Ansehen“ zeigt ihn weiterhin (aus dem JSON). Gegenprobe beim Bearbeiten (neuer Testrundgang): Punkt speichern, dann deaktivieren, Kategorie erneut speichern → im JSON (Liste RG_KategorieErgebnisse, Spalte Antworten) ist die Antwort noch drin. Prüfpunkt danach wieder aktivieren.
4. **2:** Testrundgang in SharePoint auf Status `Abschluss` setzen (simuliert den hängenden Abschluss) → Übersicht zeigt das rote Banner und – nur für Admins – „↺ Zurück auf In Arbeit“ → zweimal tippen → Status InArbeit, Mängel dieses Rundgangs entfernt, Kategorien wieder bearbeitbar. Mit einem Nicht-Admin-Konto ist der Knopf unsichtbar.

## K5 – Hinweise
- **UNSICHER (Punkt 8/9):** dass die Galerie beim Zurücksetzen zum Default-Eintrag scrollt, ist das übliche Verhalten, aber in eurer Studio-Version nicht getestet. Falls die Liste nicht springt: es schadet nicht, nur der Sprung fehlt (Rest funktioniert).
- **Punkt 2 löscht Mängel** dieses einen Rundgangs (landen im SharePoint-Papierkorb). Das ist gewollt: sie werden beim nächsten Abschluss aus den dann gültigen Antworten neu angelegt.
- Abgeschlossene Rundgänge wieder öffnen kann der Knopf bewusst **nicht** (Protokoll, Mail und Archiv wären sonst inkonsistent). Bei Bedarf als eigenes Paket.

## K6 – Rückweg
Formeln aus `C:\rundgang_work\app\yaml\` (Stand 25.10.) bzw. `app\ablage\studio_*.yaml` zurückspielen; conKaBalken und btnRuZuruecksetzen löschen. Die Zeile „Admins“ und die neuen Formeln in App.Formulas/OnStart stören nicht.
