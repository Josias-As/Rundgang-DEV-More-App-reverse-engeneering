# Paket FA – Fotos bei Mängeln + PDF-Archiv der Protokolle

Stand 26.10.2026 · passend zum App-Stand vom 25.10. **Voraussetzung: CP0 und CP1 aus `CODE_PAKETE.md` und Paket K (`PAKET_K_KERN.md`) sind eingebaut.** Die Formeln für Kategorie-OnVisible und Speichern in diesem Paket enthalten die K-Änderungen bereits. CP2 (Mail) ist unabhängig davon.

## Was am Ende passiert
1. Prüfpunkt auf **n.i.O.** → neben dem Kommentar erscheint **„📷 Foto“** → Fenster mit „Bild hinzufügen“ (Tablet: Kamera oder Galerie), Vorschau, Entfernen.
2. **Speichern** der Kategorie lädt neue Fotos sofort hoch (Bibliothek **RG_Fotos**, Ordner je Rundgang) und hängt die Links an die Antwort.
3. **Abschluss** → Mängel bekommen die Foto-Links → die App springt zum Protokoll → das Protokoll wird **automatisch als PDF** in die Bibliothek **RG_Protokolle** (Ordner Jahr/Monat) archiviert. Oben rechts dann „✓ Archiv-PDF öffnen“.
4. Klappt das Archivieren nicht (z. B. Netz weg): Knopf zeigt „⚠ Archivieren“, in der Übersicht steht „Protokoll ⚠ ›“ – einfach erneut tippen.

## Annahmen (bitte bestätigen oder ändern – Fragen von gestern)
| Punkt | Annahme in diesem Paket |
|---|---|
| Format | PDF |
| Ort | zwei neue Bibliotheken auf IMS+ (`RG_Protokolle`, `RG_Fotos`) – **nicht** das DMS |
| Rechte | wie die IMS+-Site (erben). Wenn nur FM/QM lesen dürfen: Berechtigungen der Bibliothek nachträglich anpassen |
| Aufbewahrung | noch offen → später Aufbewahrungsbezeichnung an `RG_Protokolle` (QM/IMS fragen) |
| Fotos | nur bei n.i.O., beliebig viele, ohne Personen |
| Konto für Ablage | die Flows legen Dateien mit **deinem** Konto ab (fester Ablageort, Prüfer brauchen keine Schreibrechte in den Bibliotheken) |
| Testdaten | landen im Unterordner `TEST/` |

---

## FA1 – SharePoint vorbereiten (IMS+, ca. 15 Minuten)

**Zwei Dokumentbibliotheken** (IMS+ → Neu → Dokumentbibliothek; Namen genau so, ohne Leerzeichen):
1. **RG_Protokolle** – Spalten: `DurchfuehrungID` (Zahl), `TestDatensatz` (Ja/Nein)
2. **RG_Fotos** – Spalten: `DurchfuehrungID` (Zahl), `PruefpunktID` (Zahl), `TestDatensatz` (Ja/Nein)

**Neue Spalten in bestehenden Listen:**
- **RG_Durchfuehrungen:** `ProtokollUrl` (Einzelne Textzeile), `ProtokollErstelltAm` (Datum und Uhrzeit)
- **RG_Maengel:** `FotoUrls` (Mehrere Textzeilen, Nur-Text)

Danach: Falls SharePoint die neuen Bibliotheken unter „Zuletzt verwendet“ in die linke Navigation setzt → dort entfernen (Lehre vom 25.10.).

---

## FA2 – Flow „RG_Foto_hochladen“ (Power Automate, ca. 10 Minuten)

make.powerautomate.com → Erstellen → **Sofortiger Cloud-Flow** → Trigger **„Power Apps (V2)“**. Name genau: **RG_Foto_hochladen**.

**Eingaben – genau in dieser Reihenfolge:**
1. Datei: **Foto**
2. Text: **Dateiname**
3. Text: **Ordner**
4. Zahl: **DurchfuehrungID**
5. Zahl: **PruefpunktID**
6. Ja/Nein: **Test**

**Aktionen:**
1. **SharePoint – Datei erstellen** · Websiteadresse: IMS+ · Ordnerpfad: `/RG_Fotos/` + *Ordner* · Dateiname: *Dateiname* · Dateiinhalt: *Foto (Inhalt)*
2. **SharePoint – Dateieigenschaften aktualisieren** · Bibliothek: RG_Fotos · ID: *ItemId* (aus 1) · DurchfuehrungID, PruefpunktID, TestDatensatz = *Test*
3. **Auf eine PowerApp oder einen Flow antworten** · Text-Ausgabe **url** = Ausdruck:
```
concat('https://technoformgroup.sharepoint.com/sites/IMSKonzept', replace(outputs('Datei_erstellen')?['body/Path'], ' ', '%20'))
```
(Heißt Schritt 1 bei dir anders, den Namen im Ausdruck anpassen.)

---

## FA3 – Flow „RG_Protokoll_archivieren“ (ca. 15 Minuten)

Sofortiger Cloud-Flow, Trigger **„Power Apps (V2)“**, Name genau: **RG_Protokoll_archivieren**.

**Eingaben – in dieser Reihenfolge:**
1. Text: **HTML**
2. Text: **Dateiname**
3. Text: **Ordner**
4. Zahl: **DurchfuehrungID**
5. Ja/Nein: **Test**

**Aktionen:**
0. **Einmalig vorher:** in deinem OneDrive einen Ordner **RG_Temp** anlegen.
1. **OneDrive for Business – Datei erstellen** · Ordnerpfad `/RG_Temp` · Dateiname: Ausdruck `concat(guid(), '.html')` · Inhalt: Ausdruck (Zeichensatz mitgeben, sonst können Umlaute im PDF kaputtgehen):
```
concat('<html><head><meta charset="utf-8"></head><body>', triggerBody()?['text'], '</body></html>')
```
   (`triggerBody()?['text']` ist die erste Text-Eingabe *HTML*; heißt sie bei dir anders, im Ausdruckseditor die Eingabe *HTML* auswählen.)
2. **OneDrive for Business – Datei konvertieren** · Datei: *ID* (aus 1) · Zieltyp: **PDF**
3. **SharePoint – Datei erstellen** · IMS+ · Ordnerpfad `/RG_Protokolle/` + *Ordner* · Dateiname: *Dateiname* · Inhalt: *Dateiinhalt* (aus 2)
4. **SharePoint – Dateieigenschaften aktualisieren** · RG_Protokolle · ID: *ItemId* (aus 3) · DurchfuehrungID, TestDatensatz = *Test*
5. **OneDrive for Business – Datei löschen** · Datei: *ID* (aus 1)
6. **Auf eine PowerApp oder einen Flow antworten** · Text **url** = Ausdruck wie in FA2, aber mit dem Namen von Schritt 3 (z. B. `outputs('Datei_erstellen_2')`).

**Für beide Flows:** Details → **Nur-Ausführen-Benutzer bearbeiten** → bei SharePoint und OneDrive **„Diese Verbindung verwenden“ (dein Konto)** wählen. Dann legen die Flows immer mit deinem Konto ab, egal welcher Prüfer die App bedient.

**Zum Testen ohne App:** Flow „Testen“ → manuell → kleines HTML wie `<h1>Test</h1>` → PDF muss in `RG_Protokolle/...` liegen.
*Hinweise:* Emojis (📷 ✓) können im PDF als Kästchen erscheinen (Schriftart der Umwandlung) – dann in der HTML-Formel durch Text ersetzen. Der Archiv-Dateiname enthält die Uhrzeit, ein erneutes Archivieren erzeugt also nie einen Namenskonflikt. Die Reihenfolge der Eingaben in `….Run(...)` nach dem Hinzufügen des Flows mit der Studio-Vorschlagsliste vergleichen (UNSICHER).

---

## FA4 – App anpassen (Studio, ca. 30 Minuten)

**0. Daten aktualisieren & Flows einbinden**
- Daten → bei RG_Durchfuehrungen, RG_Maengel „…“ → **Aktualisieren** (damit die neuen Spalten bekannt sind)
- Linke Leiste **Power Automate** → **Flow hinzufügen** → RG_Foto_hochladen und RG_Protokoll_archivieren

**1. App → Formulas** – ans Ende anhängen:
```
{{de:fa_App_Formulas_Zusatz}}
```
**2. App → OnStart** – ans Ende anhängen (vorher `;;` an die letzte Zeile):
```
{{de:fa_OnStart_Zusatz}}
```
Danach „OnStart ausführen“.

**3. scrKategorie → OnVisible** – komplett ersetzen:
```
{{de:fa_kat_OnVisible}}
```
**4. txtKaKommentar → Width:**
```
{{de:fa_txtKaKommentar_Width}}
```
**5. Foto-Knopf in der Karte:** `fertig\FA_btnKaFoto.yaml` → im Baum **conKaKarte** (in galKaPruefpunkte) markieren → Strg+V. **Danach Y prüfen** (Lehre: in Galerien mit flexibler Höhe friert Studio Y manchmal ein) – Soll:
`54 + If(ThisItem.Hinweis <> ""; 24; 0) + 68`

**6. Foto-Fenster:** `fertig\FA_conKaFoto.yaml` → **scrKategorie** markieren → Strg+V. Dann von Hand ergänzen:
- In **conKaFotoKarte**: Einfügen → **„Bild hinzufügen“** (bzw. „Medien hinzufügen“). Den **Knopf-Teil** umbenennen in **addKaFoto**, X `20`, Y `96`, Width `Parent.Width - 40`, Height `64`, `Visible` = `!varNurLesen`, Text „📷 Foto aufnehmen“. Ein mit eingefügtes Bild-Element (UploadedImage…) löschen.
  `addKaFoto.OnChange`:
```
{{de:fa_addKaFoto_OnChange}}
```
  (Falls nach dem Reset das Vorschaubild in der Galerie leer ist: die Zeile `Reset(Self)` entfernen – UNSICHER, beim Test prüfen.)
- In **galKaFotoNeu** (Vorlage): Einfügen → **Bild** · Image `ThisItem.Bild` · X `0` · Y `0` · Width `Parent.TemplateWidth - 8` · Height `Parent.TemplateHeight - 8` · ImagePosition „Ausfüllen“. Im Baum **unter** btnKaFotoEntfernen anordnen, damit das ✕ oben liegt.

**7. scrKategorie → btnKaSpeichern → OnSelect** – komplett ersetzen (lädt Fotos vor dem Speichern hoch; schon hochgeladene werden bei einem zweiten Versuch nicht erneut gesendet):
```
{{de:fa_ss2}}
```
**8. scrRundgang → btnRuAbschluss → OnSelect** – komplett ersetzen (Mängel mit Foto-Links, danach automatisch zum Protokoll):
```
{{de:fa_ss3}}
```
**9. scrRundgang → btnRuProtokoll → Text:**
```
{{de:fa_btnRuProtokoll_Text}}
```
**10. scrProtokoll → OnVisible** – komplett ersetzen:
```
{{de:fa_pr_OnVisible}}
```
**11. htmProtokoll → HtmlText** – komplett ersetzen (mit Foto-Links und Archiv-Link):
```
{{de:fa_htmProtokoll}}
```
**12. Archiv-Knopf + Timer:** `fertig\FA_scrProtokoll_Archiv.yaml` → **conPrKopf** markieren → Strg+V (Knopf oben rechts). Den Timer **tmrPrArchiv** danach im Baum auf **scrProtokoll** ziehen (Ausschneiden/Einfügen), falls er im Kopf gelandet ist. Formeln zur Kontrolle:
```
{{de:fa_btnPrArchivieren}}
```
```
{{de:fa_tmrPrArchiv_OnTimerEnd}}
```

App-Überprüfung → Formeln 0 → speichern.

---

## FA5 – Test (mit ZZ-Testdaten)
1. Rundgang starten → K1: einen Punkt n.i.O. → „📷 Foto“ → 2 Fotos aufnehmen → eins entfernen → Fertig → Knopf zeigt „📷 Foto (1)“.
2. Speichern → „Bitte warten“ etwas länger → gespeichert. In **RG_Fotos/TEST/2026/10/R…/** liegt 1 Foto mit DurchfuehrungID/PruefpunktID.
3. K1 erneut öffnen → „📷 Foto (1)“ → „Gespeichertes Foto öffnen“ öffnet das Bild.
4. Alle Kategorien speichern → Abschluss → App springt zum Protokoll → nach ~1–3 s „Protokoll als PDF archiviert“, oben „✓ Archiv-PDF öffnen“ → PDF in **RG_Protokolle/TEST/2026/10/** enthält alle Kategorien, n.i.O. rot, „📷 Foto“-Link.
5. RG_Maengel: Zeile des Mangels hat `FotoUrls`. RG_Durchfuehrungen: `ProtokollUrl` und `ProtokollErstelltAm` gefüllt.
6. Fehlerfall: Flow RG_Protokoll_archivieren kurz ausschalten → Abschluss eines zweiten Testrundgangs → Meldung „konnte nicht archiviert werden“, Knopf „⚠ Archivieren“; Flow einschalten → Knopf tippen → archiviert.
7. Danach Testdateien in `TEST/`-Ordnern und Testzeilen löschen.

## FA6 – Rückweg
App: Formeln aus `C:\rundgang_work\app\yaml\` (Stand 25.10.) bzw. Git zurückspielen, btnKaFoto/conKaFoto/btnPrArchivieren/tmrPrArchiv löschen. Flows ausschalten/löschen. Bibliotheken und Spalten können bleiben (stören nicht) oder gelöscht werden.

## Zeitbedarf und Performance (geschlussfolgert)
- Speichern ohne Fotos: unverändert (~2,6 s). Je Foto ca. +1–3 s (Größe/Netz).
- Archivieren: ca. 3–8 s im Hintergrund nach dem Abschluss (Flow mit Umwandlung); die App bleibt bedienbar, sobald „Bitte warten“ verschwindet.
