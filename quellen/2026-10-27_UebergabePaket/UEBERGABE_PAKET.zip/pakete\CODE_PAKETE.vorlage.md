# Code-Pakete – nächste Änderungen der Rundgang-App

Stand 26.10.2026 · passend zum App-Stand vom 25.10. (Namen exakt wie in deiner App). Gesamtreihenfolge mit den anderen Paketen: **CP0 → CP1 → K → CP3 → CP4 → FA → CP2** (CP2 erst nach Outlook-Verbindung).

**So fügst du ein (gilt für alle Pakete)**
- **YAML-Bausteine** (`pakete\fertig\*.yaml`): Datei im Editor öffnen → Strg+A → Strg+C → in Studio das Ziel im Baum markieren (steht beim Paket) → Strg+V. Die YAML ist in „Datei-Schreibweise“ (Kommas) – das ist richtig so, Studio übersetzt beim Einfügen selbst.
- **Formeln in der Formelleiste**: immer die hier abgedruckte **deutsche** Fassung (Semikolons) nehmen. Eigenschaft oben links auswählen, Formelleiste Strg+A, einfügen.
- **Vorher**: Vorschau beenden. **Nachher**: App-Überprüfung → Formeln = 0, dann speichern (Strg+S).
- Landet ein Baustein außerhalb des gewünschten Containers: im Baum Rechtsklick → Ausschneiden, Container markieren → Einfügen.

---

## CP0 – Vorbereitung (1 Minute, Pflicht vor CP1–CP3)

**App → OnStart**: ans Ende der vorhandenen Formel anhängen (vor der letzten Zeile ein `;;` setzen, falls die letzte Zeile keins hat):
```
{{de:cpX_OnStart_Zusatz}}
```
**App → Formulas**: ans Ende anhängen:
```
{{de:cp1_fnHtml}}
```
Danach oben „…“ → „OnStart ausführen“ (oder App einmal neu laden), damit die Variablen existieren.

---

## CP1 – Protokoll-Screen (ohne Freigabe machbar, ca. 15 Minuten)

**Nutzen:** Nach dem Abschluss sieht der Prüfer ein sauberes Protokoll aller Antworten (Mängel rot). Genau dieser Inhalt wird später in CP2 per Mail verschickt.

1. **Screen einfügen:** `fertig\CP1_scrProtokoll.yaml` kopieren → im Baum **scrRundgang** markieren → Strg+V. Es entsteht `scrProtokoll` (Kopf, Inhaltsbereich `conPrInhalt`, Fuß mit Mail-Status, Lade-Overlay).
   - Falls `LayoutOverflowY` beim Einfügen bemängelt wird: Zeile löschen und bei `conPrInhalt` rechts im Eigenschaftenbereich **Vertikaler Überlauf = Scrollen** setzen.
2. **HTML-Steuerelement:** `conPrInhalt` markieren → Einfügen → **HTML-Text** → umbenennen in **htmProtokoll**. Eigenschaften:
   - `AutoHeight` (Automatische Höhe) = `true`
   - `Width` = `Parent.Width - 32`
   - `PaddingTop/Bottom/Left/Right` = `0`
   - `HtmlText` =
```
{{de:cp1_htmProtokoll}}
```
3. **Knopf in der Übersicht:** `fertig\CP1_btnRuProtokoll.yaml` kopieren → im Baum **conRuKopf** (scrRundgang) markieren → Strg+V. Erscheint nur bei abgeschlossenen Rundgängen oben rechts „Protokoll ›“.

**Test:** Rundgang abschließen → „Protokoll ›“ → alle Kategorien, n.i.O. rot mit Kommentar, Zahl mit Einheit (18,5 °C), Fuß „noch nicht per Mail versendet“. Text mit `<` oder `&` im Kommentar wird korrekt angezeigt (fnHtml).
**Rückweg:** scrProtokoll und btnRuProtokoll löschen; fnHtml und die zwei OnStart-Zeilen stören nicht.

---

## CP2 – Protokoll-Mail (SS4) – **erst nach Freigabe**

**Voraussetzung:** Daten → Daten hinzufügen → **Office 365 Outlook** (Standard-Konnektor) mit deinem Konto. Der Name in der App ist dann `Office365Outlook`. RG_Konfiguration: Testmodus = Ja, Testadresse = deine Adresse (steht schon so).

1. `fertig\CP2_btnPrSenden.yaml` kopieren → im Baum **conPrFuss** (scrProtokoll) markieren → Strg+V. Knopf rechts im Fuß „Per Mail senden“ / „Erneut senden“.
2. Die Formel (OnSelect) ist schon drin; deutsche Fassung zum Prüfen/Nachtragen:
```
{{de:cp2_btnPrSenden}}
```
**Was sie tut:** Zweifach-Sperre gegen Doppeltippen · liest den Rundgang frisch · nur bei „Abgeschlossen“ · Empfänger aus der Konfiguration (Testmodus → Testadresse, Betreff beginnt mit „TEST –“, fehlt die Zeile „Testmodus“, gilt trotzdem Testmodus) · Mängel → Wichtigkeit hoch · danach `MailGesendetAm` setzen und nachlesen.
**Test:** einmal senden → Mail kommt an, Fuß zeigt „Versendet am …“; Doppeltipp → nur eine Mail; Testadresse in der Konfiguration leeren → Fehlermeldung statt Versand.
**Rückweg:** btnPrSenden löschen; Outlook-Datenquelle entfernen.

---

## CP3 – Schnellknopf „Offene auf i.O.“ – **VERWORFEN (26.10.2026, Josias): nicht einbauen**

> Grund: Die Prüfer sind nicht immer verantwortungsbewusst. Heute werden schon Felder mit „gzgz“ gefüllt. Der Knopf würde das Durchklicken zusätzlich erleichtern und Mängel verdecken. Der Zwang, jeden Punkt bewusst zu beantworten, ist gewollt. (Der Rest dieses Abschnitts bleibt nur zur Dokumentation.)

## (verworfen) CP3 – Schnellknopf – ca. 5 Minuten, erst nach Paket K

> Die Formeln nutzen das Feld `Inaktiv` aus Paket K (ausgeblendete Antworten deaktivierter Prüfpunkte werden nicht angefasst). Deshalb CP3 erst nach K einbauen.

**Nutzen:** Bei Kategorien mit vielen Prüfpunkten, die fast immer in Ordnung sind: erst die Auffälligen auf n.i.O. setzen, dann alle übrigen mit einem Knopf auf i.O. – mit Sicherheitsabfrage (zweites Tippen). Zahl/Auswahl/Text bleiben unberührt.

1. `fertig\CP3_btnKaAlleIO.yaml` kopieren → im Baum **conKaKopf** (scrKategorie) markieren → Strg+V. Knopf oben rechts im Kopf, nur sichtbar, wenn noch offene i.O./n.i.O.-Punkte da sind und nicht „nur Ansicht“. (Das Zurücksetzen der Sicherheitsabfrage beim Öffnen ist schon im OnVisible aus Paket K enthalten.)
**Test:** Kategorie mit 2 offenen Punkten → „Offene 2 auf i.O.“ → 1. Tippen: grün „Wirklich 2 × i.O.? Erneut tippen“ → 2. Tippen: beide i.O., Knopf verschwindet; Zurück fragt „Verwerfen?“ (Änderung erkannt).
**Rückweg:** btnKaAlleIO löschen.

---

## CP4 – Offene Rundgänge früherer Tage auf dem Startscreen (ca. 10 Minuten)

**Nutzen:** Ein nicht abgeschlossener Rundgang von gestern oder früher geht nicht mehr verloren: unten erscheint ein roter Hinweis mit „Öffnen“ (Frage F3).

1. **scrStart → btnStartTagLaden → OnSelect** komplett ersetzen:
```
{{de:cp4_btnStartTagLaden}}
```
2. `fertig\CP4_conStartOffen.yaml` kopieren → im Baum **scrStart** markieren → Strg+V.
3. **galStartRundgaenge → Height**:
```
{{de:cp4_galHoehe}}
```
(Die OnSelect-Formel von „Öffnen“ ist im Baustein; deutsch zur Kontrolle:)
```
{{de:cp4_btnStartOffen}}
```
**Test:** Durchführung von gestern im Status InArbeit vorhanden → Startscreen zeigt roten Hinweis → „Öffnen“ → Kategorien des alten Rundgangs, weiterarbeiten und abschließen möglich. Ohne alte offene Rundgänge: kein Hinweis, Liste volle Höhe.
**Rückweg:** conStartOffen löschen, Height zurück auf `Parent.Height - 256`, OnSelect ohne die colOffenAlt-Zeile.

---

## Nach jedem Paket
App-Überprüfung (Formeln 0) → Vorschau-Test wie oben → speichern. Wenn ich wieder einsteigen soll, sag Bescheid – ich hole mir dann den aktuellen Stand aus Studio.
