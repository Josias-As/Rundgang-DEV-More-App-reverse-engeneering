# Ideen-Pakete – die Rundgang-App cooler und nützlicher machen

Stand 26.10.2026. Jede Idee mit **Nutzen**, **Wie** (technisch, passend zu eurer Umgebung: Power Apps + SharePoint, ohne Premium), **Aufwand** (S = Stunden, M = 1 Tag, L = mehrere Tage) und **Haken**. Kennzeichnung: geschlussfolgert, wo nicht anders gesagt.

## A – Schnell spürbar (kleiner Aufwand, großer Effekt)

**A1 „Was war letztes Mal?“ – Hinweis am Prüfpunkt**
- *Nutzen:* Der Prüfer sieht direkt am Prüfpunkt: „Letztes Mal n.i.O. (12.10.): Klima tropft“. Wiederholungsmängel fallen sofort auf, statt jedes Mal neu entdeckt zu werden.
- *Wie:* beim Öffnen der Kategorie die letzte Ergebniszeile derselben Kategorie laden (`Filter(RG_KategorieErgebnisse, KategorieID = varKatID)` → neueste), JSON parsen, in `colAntworten` eine Spalte `Vorher` ergänzen, kleines graues Label unter der Frage.
- *Aufwand:* S–M · *Haken:* eine zusätzliche Abfrage beim Öffnen (~200 ms).

**A2 Zählerstände vorbelegen + Plausibilität**
- *Nutzen:* Bei „Betriebsstunden“ & Co. steht der letzte Wert als Hinweis daneben. Ist der neue Wert kleiner als der alte, gibt es eine Warnung (Tippfehler wie 1243 statt 12430 fallen auf).
- *Wie:* wie A1 (letzter `WertZahl`), Regel „Zähler darf nicht sinken“ als neue Spalte `Zaehler` (Ja/Nein) in RG_Pruefpunkte.
- *Aufwand:* S · *Haken:* neue Spalte in der Liste (einmal im Listen-Skript ergänzen).

**A3 Fortschrittsring statt Balken + „noch 3 Kategorien · ca. 12 min“**
- *Nutzen:* motiviert und hilft bei der Zeitplanung. Die Restzeit wird aus der Dauer der letzten Rundgänge geschätzt.
- *Wie:* StartZeit/GespeichertAm je Kategorie sind schon gespeichert → Durchschnitt je Kategorie aus den letzten 5 Durchführungen. Ring als SVG-Bild (`"data:image/svg+xml;utf8," & EncodeUrl(...)`).
- *Aufwand:* S–M.

**A4 Große „Daumen“-Bedienung für Handschuhe**
- *Nutzen:* i.O./n.i.O. als große Kacheln (ganze Kartenbreite halbiert), optional Wischgeste (nach rechts = i.O.).
- *Wie:* Buttons auf 50 % Kartenbreite, Höhe 72; Wischen über ein transparentes Feld mit `OnSelect` + Tippposition ist in Canvas nur eingeschränkt möglich → lieber große Kacheln.
- *Aufwand:* S · *Haken:* Wischen nicht nativ (UNSICHER, ob sich das lohnt).

**A5 Sprachkommentar per Diktat**
- *Nutzen:* Kommentar bei n.i.O. sprechen statt tippen (mit Handschuhen Gold wert).
- *Wie:* nichts zu bauen – die Tablet-Tastatur hat ein Mikrofon. Nur im Hinweistext des Kommentarfelds erwähnen: „Tipp: Mikrofon auf der Tastatur“.
- *Aufwand:* S (5 Minuten).

## B – Spürbar mehr Funktion (mittlerer Aufwand)

**B1 Foto beim Mangel**
- *Nutzen:* n.i.O. + Foto → der Haustechniker sieht sofort, was gemeint ist. Das ist der größte Komfortgewinn gegenüber Papier und MoreApp-Text.
- *Wie:* Steuerelement „Bild hinzufügen“ (AddMedia) in der Karte bei n.i.O. → Bild beim Abschluss als **Anlage an die Mängelzeile** (SharePoint-Anlagen über ein Formular-Steuerelement) oder in eine Dokumentbibliothek „RG_Fotos“ mit Schlüssel `D…-P…`.
- *Aufwand:* M–L · *Haken:* Anlagen aus Canvas heraus gehen nur über ein Edit-Formular. Fotos verkleinern (Kamera-Auflösung), sonst wird es auf schwachem Netz langsam. Die Entscheidung Bibliothek oder Anlage ist vorher zu treffen.

**B2 QR-Code an jedem Raum = „Ich war wirklich da“**
- *Nutzen:* Die Kategorie öffnet sich nur (oder schneller), wenn der QR-Code am Raum gescannt wurde. Das dient als Nachweis vor Ort und ist ein schöner „Wow“-Effekt.
- *Wie:* Barcode-Scanner-Steuerelement (Standard, mobil) → gescannter Text = `KategorieID` → direkt öffnen. QR-Aufkleber mit der Kategorie-ID drucken.
- *Aufwand:* M · *Haken:* Scanner funktioniert nur in der Power-Apps-Mobile-App, nicht im Browser. Pflicht oder optional ist eine Fachentscheidung.

**B3 Mängel-Cockpit „Offene Mängel“**
- *Nutzen:* eigener Screen: alle offenen Mängel nach Bereich, Alter in Tagen, mit Knopf „erledigt“ inklusive Erledigt-Kommentar. Schließt die Lücke „Mängel nachverfolgen“ aus der Planner-Aufgabe.
- *Wie:* Galerie auf `Filter(RG_Maengel, Status = "Offen")`, Statuswechsel per Patch mit den fünf Schutzschichten, neue Spalten `ErledigtAm/ErledigtVon/ErledigtKommentar`.
- *Aufwand:* M · *Haken:* Rollenfrage (wer darf erledigen? → F5).

**B4 Trend-Minikurve für Messwerte**
- *Nutzen:* Wassertemperatur der letzten 10 Rundgänge als kleine Linie neben dem Eingabefeld, mit Sollband. Schleichende Abweichungen werden sichtbar, bevor sie zum Mangel werden.
- *Wie:* letzte Werte aus RG_KategorieErgebnisse (JSON) → SVG-Polyline als Bild.
- *Aufwand:* M.

**B5 Unterschrift im Protokoll**
- *Nutzen:* Der Prüfer (optional auch der Haustechniker) unterschreibt auf dem Tablet, die Unterschrift steht im Protokoll und in der Mail.
- *Wie:* Stifteingabe (Pen input) auf scrProtokoll, Bild als Base64 in `RG_Durchfuehrungen` (mehrzeiliger Text) → im HTML als `<img src='data:…'>`.
- *Aufwand:* M · *Haken:* Base64 ist groß (ca. 20–60 KB); manche Mailprogramme blockieren eingebettete Bilder (UNSICHER für Outlook intern).

**B6 Protokoll als PDF im Archiv**
- *Nutzen:* erfüllt „Rundgangsprotokolle archivieren“ aus der Planner-Checkliste.
- *Wie:* Canvas-`PDF()`-Funktion (Vorschaufunktion, UNSICHER ob bei euch freigeschaltet) oder ein Flow „HTML → PDF in Bibliothek“ (Flow = eigene Freigabe).
- *Aufwand:* M–L.

## C – Größere Schritte (später, mit Fachbereich)

**C1 Offline-Modus für Funklöcher (Keller, Serverraum)**
- *Nutzen:* Der Rundgang geht auch ohne Netz weiter, synchronisiert wird später.
- *Wie:* `SaveData/LoadData` (bei euch aktiviert), Speichern in eine lokale Warteschlange, beim nächsten Netz die SS2-Logik nachholen.
- *Aufwand:* L · *Haken:* Konflikte mit anderen Tablets. Erst sinnvoll, wenn J2 (Netzmessung) Funklöcher zeigt.

**C2 Kennzahlen für die FM-Leitung**
- *Nutzen:* Erfüllungsquote (geplante vs. durchgeführte Rundgänge), Mängel je Bereich und Monat, Top-5-Wiederholungsmängel.
- *Wie:* Screen mit einfachen Balken (Galerie mit Rechtecken) oder Power BI auf die SharePoint-Listen.
- *Aufwand:* M (App) / L (Power BI).

**C3 Mangel → Aufgabe für den Haustechniker**
- *Nutzen:* Jeder Mangel wird automatisch eine Planner- oder Teams-Aufgabe mit Foto und Link.
- *Wie:* Flow auf „Element erstellt“ in RG_Maengel.
- *Aufwand:* M · *Haken:* Flows sind nach den Leitplanken nur mit eigener Freigabe erlaubt.

**C4 Erinnerung „Rundgang heute noch offen“**
- *Nutzen:* Um 14 Uhr bekommt der Zuständige eine Teams- oder Mail-Nachricht, wenn der Rundgang des Tages noch nicht abgeschlossen ist.
- *Wie:* geplanter Flow, der RG_Plan/RG_Durchfuehrungen nur liest (siehe Konzept „V1.1“).
- *Aufwand:* M.

**C5 Admin-Screen für Stammdaten**
- *Nutzen:* Rundgänge, Kategorien und Prüfpunkte direkt in der App pflegen (Reihenfolge per Hoch/Runter, Prüfpunkt deaktivieren mit Warnung, wenn heute ein Rundgang läuft → löst F4).
- *Wie:* eigener Screen, nur für Pflege-Rolle sichtbar (Konfigurationszeile „Admins“).
- *Aufwand:* L.

## Meine Empfehlung (Reihenfolge)
1. **A5 + A1 + A2:** fast geschenkt, sofort spürbar im Alltag.
2. **CP1–CP2 + B6:** Protokoll, Mail und Archiv erfüllen die Planner-Checkliste.
3. **B1 Foto + B3 Mängel-Cockpit:** der größte echte Mehrwert gegenüber MoreApp.
4. **B2 QR-Code:** der „coole“ Faktor, wenn der Fachbereich Nachweis vor Ort will.
5. **C-Pakete:** erst nach Tablet-Test, Netzmessung und Fachentscheidungen.
