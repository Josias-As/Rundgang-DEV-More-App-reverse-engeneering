# FRAGEN AN JOSIAS – Rundgangs-App

**F1 – Freigabe SS4 (Protokoll-Mail) – nötig für R16**
Für die Protokoll-Mail muss ich in der App die Datenquelle **Office 365 Outlook** (Standard-Konnektor, keine Premium-Lizenz) über dein Konto verbinden und **eine Test-Mail** auslösen. Im Testmodus geht sie nur an die Testadresse aus RG_Konfiguration = josias.assefaw@technoform.com, Betreff mit „TEST“. Darf ich (a) die Outlook-Verbindung hinzufügen und (b) eine Test-Mail an dich senden?

**F2 – Veröffentlichen für den Tablet-Test (J1)**
Damit du die App auf dem Tablet öffnen kannst, muss der aktuelle Stand einmal **veröffentlicht** werden (nur für dich, die App ist nicht geteilt). Soll ich das machen, oder machst du es selbst (oben rechts „Veröffentlichen“)?

**F3 – Rundgang über Mitternacht (fachlich)**
Ein Rundgang, der nicht am selben Tag abgeschlossen wird, ist nur innerhalb von `NachholTage` (jetzt 1 = gestern) erreichbar. Reicht das, oder sollen offene Rundgänge älterer Tage immer auf dem Startbildschirm erscheinen?

**F4 – Stammdatenpflege während laufender Rundgänge (fachlich)**
Wenn ein Prüfpunkt deaktiviert wird, während ein Rundgang des Tages läuft, kann dessen Antwort beim erneuten Speichern der Kategorie verloren gehen. Vorschlag: Stammdaten nur nach Feierabend pflegen (organisatorische Regel). Einverstanden, oder soll die App das abfangen (Mehraufwand)?

**F5 – Was passiert mit Mängeln danach? (fachlich, für später)**
RG_Maengel hat Status „Offen“. Wer bearbeitet/schließt Mängel, und braucht es dafür eine Ansicht in der App oder reicht die SharePoint-Liste?

**Antworten 26.10.2026:** Flows legen mit Josias' Konto ab · Protokolle/Fotos fuer alle IMS+-Mitglieder lesbar (Rechte erben) · Admin nur Josias. Einbau startet mit pakete\SCHRITT_1_GRUNDLAGEN.md, dann CP1 -> K -> CP3 -> CP4 -> FA -> CP2.
