# Paket FA – Fotos bei Mängeln + PDF-Archiv der Protokolle

Stand 26.10.2026 · passend zum App-Stand vom 25.10. **Voraussetzung: CP0 und CP1 aus `CODE_PAKETE.md` und Paket K (`PAKET_K_KERN.md`) sind eingebaut.** Die Formeln für Kategorie-OnVisible und Speichern in diesem Paket enthalten die K-Änderungen bereits. CP2 (Mail) ist unabhängig davon.

## Was am Ende passiert
1. Prüfpunkt auf **n.i.O.** → neben dem Kommentar erscheint **„📷 Foto“** → Fenster mit „Bild hinzufügen“ (Tablet: Kamera oder Galerie), Vorschau, Entfernen.
2. **Speichern** der Kategorie lädt neue Fotos sofort hoch (Bibliothek **RG_Fotos**, Ordner je Rundgang) und hängt die Links an die Antwort.
3. **Abschluss** → Mängel bekommen die Foto-Links → die App springt zum Protokoll → das Protokoll wird **automatisch als PDF** in die Bibliothek **RG_Protokolle** (Ordner Jahr/Monat) archiviert. Oben rechts dann „✓ Archiv-PDF öffnen“.
4. Klappt das Archivieren nicht (z. B. Netz weg): Knopf zeigt „⚠ Archivieren“, in der Übersicht steht „Protokoll ⚠ ›“ – einfach erneut tippen.

## Annahmen (bitte bestätigen oder ändern – Fragen von gestern)
| Punkt | Annahme in diesem Paket |
|---|---|
| Format | PDF |
| Ort | zwei neue Bibliotheken auf IMS+ (`RG_Protokolle`, `RG_Fotos`) – **nicht** das DMS |
| Rechte | wie die IMS+-Site (erben). Wenn nur FM/QM lesen dürfen: Berechtigungen der Bibliothek nachträglich anpassen |
| Aufbewahrung | noch offen → später Aufbewahrungsbezeichnung an `RG_Protokolle` (QM/IMS fragen) |
| Fotos | nur bei n.i.O., beliebig viele, ohne Personen |
| Konto für Ablage | die Flows legen Dateien mit **deinem** Konto ab (fester Ablageort, Prüfer brauchen keine Schreibrechte in den Bibliotheken) |
| Testdaten | landen im Unterordner `TEST/` |

---

## FA1 – SharePoint vorbereiten (IMS+, ca. 15 Minuten)

**Zwei Dokumentbibliotheken** (IMS+ → Neu → Dokumentbibliothek; Namen genau so, ohne Leerzeichen):
1. **RG_Protokolle** – Spalten: `DurchfuehrungID` (Zahl), `TestDatensatz` (Ja/Nein)
2. **RG_Fotos** – Spalten: `DurchfuehrungID` (Zahl), `PruefpunktID` (Zahl), `TestDatensatz` (Ja/Nein)

**Neue Spalten in bestehenden Listen:**
- **RG_Durchfuehrungen:** `ProtokollUrl` (Einzelne Textzeile), `ProtokollErstelltAm` (Datum und Uhrzeit)
- **RG_Maengel:** `FotoUrls` (Mehrere Textzeilen, Nur-Text)

Danach: Falls SharePoint die neuen Bibliotheken unter „Zuletzt verwendet“ in die linke Navigation setzt → dort entfernen (Lehre vom 25.10.).

---

## FA2 – Flow „RG_Foto_hochladen“ (Power Automate, ca. 10 Minuten)

make.powerautomate.com → Erstellen → **Sofortiger Cloud-Flow** → Trigger **„Power Apps (V2)“**. Name genau: **RG_Foto_hochladen**.

**Eingaben – genau in dieser Reihenfolge:**
1. Datei: **Foto**
2. Text: **Dateiname**
3. Text: **Ordner**
4. Zahl: **DurchfuehrungID**
5. Zahl: **PruefpunktID**
6. Ja/Nein: **Test**

**Aktionen:**
1. **SharePoint – Datei erstellen** · Websiteadresse: IMS+ · Ordnerpfad: `/RG_Fotos/` + *Ordner* · Dateiname: *Dateiname* · Dateiinhalt: *Foto (Inhalt)*
2. **SharePoint – Dateieigenschaften aktualisieren** · Bibliothek: RG_Fotos · ID: *ItemId* (aus 1) · DurchfuehrungID, PruefpunktID, TestDatensatz = *Test*
3. **Auf eine PowerApp oder einen Flow antworten** · Text-Ausgabe **url** = Ausdruck:
```
concat('https://technoformgroup.sharepoint.com/sites/IMSKonzept', replace(outputs('Datei_erstellen')?['body/Path'], ' ', '%20'))
```
(Heißt Schritt 1 bei dir anders, den Namen im Ausdruck anpassen.)

---

## FA3 – Flow „RG_Protokoll_archivieren“ (ca. 15 Minuten)

Sofortiger Cloud-Flow, Trigger **„Power Apps (V2)“**, Name genau: **RG_Protokoll_archivieren**.

**Eingaben – in dieser Reihenfolge:**
1. Text: **HTML**
2. Text: **Dateiname**
3. Text: **Ordner**
4. Zahl: **DurchfuehrungID**
5. Ja/Nein: **Test**

**Aktionen:**
0. **Einmalig vorher:** in deinem OneDrive einen Ordner **RG_Temp** anlegen.
1. **OneDrive for Business – Datei erstellen** · Ordnerpfad `/RG_Temp` · Dateiname: Ausdruck `concat(guid(), '.html')` · Inhalt: Ausdruck (Zeichensatz mitgeben, sonst können Umlaute im PDF kaputtgehen):
```
concat('<html><head><meta charset="utf-8"></head><body>', triggerBody()?['text'], '</body></html>')
```
   (`triggerBody()?['text']` ist die erste Text-Eingabe *HTML*; heißt sie bei dir anders, im Ausdruckseditor die Eingabe *HTML* auswählen.)
2. **OneDrive for Business – Datei konvertieren** · Datei: *ID* (aus 1) · Zieltyp: **PDF**
3. **SharePoint – Datei erstellen** · IMS+ · Ordnerpfad `/RG_Protokolle/` + *Ordner* · Dateiname: *Dateiname* · Inhalt: *Dateiinhalt* (aus 2)
4. **SharePoint – Dateieigenschaften aktualisieren** · RG_Protokolle · ID: *ItemId* (aus 3) · DurchfuehrungID, TestDatensatz = *Test*
5. **OneDrive for Business – Datei löschen** · Datei: *ID* (aus 1)
6. **Auf eine PowerApp oder einen Flow antworten** · Text **url** = Ausdruck wie in FA2, aber mit dem Namen von Schritt 3 (z. B. `outputs('Datei_erstellen_2')`).

**Für beide Flows:** Details → **Nur-Ausführen-Benutzer bearbeiten** → bei SharePoint und OneDrive **„Diese Verbindung verwenden“ (dein Konto)** wählen. Dann legen die Flows immer mit deinem Konto ab, egal welcher Prüfer die App bedient.

**Zum Testen ohne App:** Flow „Testen“ → manuell → kleines HTML wie `<h1>Test</h1>` → PDF muss in `RG_Protokolle/...` liegen.
*Hinweise:* Emojis (📷 ✓) können im PDF als Kästchen erscheinen (Schriftart der Umwandlung) – dann in der HTML-Formel durch Text ersetzen. Der Archiv-Dateiname enthält die Uhrzeit, ein erneutes Archivieren erzeugt also nie einen Namenskonflikt. Die Reihenfolge der Eingaben in `….Run(...)` nach dem Hinzufügen des Flows mit der Studio-Vorschlagsliste vergleichen (UNSICHER).

---

## FA4 – App anpassen (Studio, ca. 30 Minuten)

**0. Daten aktualisieren & Flows einbinden**
- Daten → bei RG_Durchfuehrungen, RG_Maengel „…“ → **Aktualisieren** (damit die neuen Spalten bekannt sind)
- Linke Leiste **Power Automate** → **Flow hinzufügen** → RG_Foto_hochladen und RG_Protokoll_archivieren

**1. App → Formulas** – ans Ende anhängen:
```
fnDateiname(t: Text): Text = Trim(Substitute(Substitute(Substitute(Substitute(Substitute(Substitute(Substitute(Substitute(Substitute(Substitute(Substitute(Substitute(t; "\"; "-"); "/"; "-"); ":"; "-"); "*"; ""); "?"; ""); """"; ""); "<"; ""); ">"; ""); "|"; "-"); "#"; ""); "%"; ""); "'"; ""));;
fnArchivOrdner(tag: Text; test: Boolean): Text = If(test; "TEST/"; "") & Left(tag; 4) & "/" & Mid(tag; 6; 2);;
```
**2. App → OnStart** – ans Ende anhängen (vorher `;;` an die letzte Zeile):
```
Set(varFotoPP; 0);;
Set(varArchivStart; false);;
```
Danach „OnStart ausführen“.

**3. scrKategorie → OnVisible** – komplett ersetzen:
```
Set(varIsLoading; true);;
Set(varZurueckFrage; false);;
Set(varAlleIOFrage; false);;
Set(varZeigeFehlend; false);;
Set(varFotoPP; 0);;
Clear(colFotos);;
Set(varGeaendert; false);;
Set(varSchluesselK; "D" & varDurchID & "-K" & varKatID);;
Set(varNurLesen; varDurch.Status <> stInArbeit);;
Refresh(RG_KategorieErgebnisse);;
Concurrent(
    ClearCollect(colPP; Filter(RG_Pruefpunkte; KategorieID = varKatID && Aktiv = true));
    Set(varErgebnis; LookUp(RG_KategorieErgebnisse; Title = varSchluesselK))
);;
Set(varGespeichertBeimOeffnen; varErgebnis.GespeichertAm);;
With({t: If(IsBlank(varErgebnis.Antworten); Table(ParseJSON("[]")); Table(ParseJSON(varErgebnis.Antworten)))};
    If(varNurLesen && !IsEmpty(t);
        // (3) Nur-Ansicht: genau das anzeigen, was gespeichert wurde (unabhängig von späteren Stammdaten-Änderungen)
        ClearCollect(colAntworten;
            ForAll(Sequence(CountRows(t)) As i;
                With({a: Index(t; i.Value).Value};
                    With({pp: LookUp(colPP; ID = Value(a.PruefpunktID))};
                        {PruefpunktID: Value(a.PruefpunktID); Frage: Text(a.Frage); Typ: Text(a.Typ); Pflicht: false; Einheit: Coalesce(Text(a.Einheit); ""); MinWert: pp.MinWert; MaxWert: pp.MaxWert; Auswahl: Coalesce(Text(a.WertText); ""); Hinweis: ""; Reihenfolge: i.Value;
                         Bewertung: Coalesce(Text(a.Bewertung); ""); WertText: Coalesce(Text(a.WertText); ""); WertZahl: Value(a.WertZahl); Kommentar: Coalesce(Text(a.Kommentar); ""); Fotos: Coalesce(Text(a.Fotos); ""); Inaktiv: false}
                    )
                )
            )
        );
        // Bearbeiten: aktive Prüfpunkte aus den Stammdaten, vorbelegt aus dem gespeicherten JSON
        ClearCollect(colAntworten;
            ForAll(Sort(colPP; RgReihenfolge) As p;
                With({alt: LookUp(t As j; Value(j.Value.PruefpunktID) = p.ID)};
                    {PruefpunktID: p.ID; Frage: p.Title; Typ: p.Eingabetyp.Value; Pflicht: p.Pflicht; Einheit: Coalesce(p.Einheit; ""); MinWert: p.MinWert; MaxWert: p.MaxWert; Auswahl: Coalesce(p.Auswahlwerte; ""); Hinweis: Coalesce(p.Hinweis; ""); Reihenfolge: p.RgReihenfolge;
                     Bewertung: If(IsBlank(alt); ""; p.Eingabetyp.Value = "ZAHL" && !IsBlank(alt.Value.WertZahl); fnZahlBewertung(Value(alt.Value.WertZahl); p.MinWert; p.MaxWert); Coalesce(Text(alt.Value.Bewertung); ""));
                     WertText: If(IsBlank(alt); ""; Coalesce(Text(alt.Value.WertText); ""));
                     WertZahl: If(IsBlank(alt); Blank(); Value(alt.Value.WertZahl));
                     Kommentar: If(IsBlank(alt); ""; Coalesce(Text(alt.Value.Kommentar); ""));
                     Fotos: If(IsBlank(alt); ""; Coalesce(Text(alt.Value.Fotos); ""));
                     Inaktiv: false}
                )
            )
        );;
        // (3b) Antworten inzwischen deaktivierter Prüfpunkte unverändert mitführen: ausgeblendet, gehen beim Speichern nicht verloren
        Collect(colAntworten;
            ForAll(Filter(t As j2; IsBlank(LookUp(colPP; ID = Value(j2.Value.PruefpunktID)))) As o;
                {PruefpunktID: Value(o.Value.PruefpunktID); Frage: Text(o.Value.Frage); Typ: Text(o.Value.Typ); Pflicht: false; Einheit: Coalesce(Text(o.Value.Einheit); ""); MinWert: Blank(); MaxWert: Blank(); Auswahl: ""; Hinweis: ""; Reihenfolge: 100000 + Value(o.Value.PruefpunktID);
                 Bewertung: Coalesce(Text(o.Value.Bewertung); ""); WertText: Coalesce(Text(o.Value.WertText); ""); WertZahl: Value(o.Value.WertZahl); Kommentar: Coalesce(Text(o.Value.Kommentar); ""); Fotos: Coalesce(Text(o.Value.Fotos); ""); Inaktiv: true}
            )
        )
    )
);;
// (8) Liste immer oben beginnen
Set(varSprungRec; First(Sort(Filter(colAntworten; !Inaktiv); Reihenfolge)));;
Reset(galKaPruefpunkte);;
Set(varIsLoading; false)
```
**4. txtKaKommentar → Width:**
```
Parent.Width - 196
```
**5. Foto-Knopf in der Karte:** `fertig\FA_btnKaFoto.yaml` → im Baum **conKaKarte** (in galKaPruefpunkte) markieren → Strg+V. **Danach Y prüfen** (Lehre: in Galerien mit flexibler Höhe friert Studio Y manchmal ein) – Soll:
`54 + If(ThisItem.Hinweis <> ""; 24; 0) + 68`

**6. Foto-Fenster:** `fertig\FA_conKaFoto.yaml` → **scrKategorie** markieren → Strg+V. Dann von Hand ergänzen:
- In **conKaFotoKarte**: Einfügen → **„Bild hinzufügen“** (bzw. „Medien hinzufügen“). Den **Knopf-Teil** umbenennen in **addKaFoto**, X `20`, Y `96`, Width `Parent.Width - 40`, Height `64`, `Visible` = `!varNurLesen`, Text „📷 Foto aufnehmen“. Ein mit eingefügtes Bild-Element (UploadedImage…) löschen.
  `addKaFoto.OnChange`:
```
If(!IsBlank(Self.Media);
    // Dateiname schon jetzt festlegen: bei einem Wiederholungsversuch entsteht keine zweite Datei
    Collect(colFotos; {PruefpunktID: varFotoPP; Nr: Coalesce(Max(colFotos; Nr); 0) + 1; Bild: Self.Media; Datei: varSchluesselK & "-P" & varFotoPP & "-" & Left(Text(GUID()); 8) & ".jpg"; Url: ""; Uebernommen: false});;
    Set(varGeaendert; true);;
    Reset(Self)
)
```
  (Falls nach dem Reset das Vorschaubild in der Galerie leer ist: die Zeile `Reset(Self)` entfernen – UNSICHER, beim Test prüfen.)
- In **galKaFotoNeu** (Vorlage): Einfügen → **Bild** · Image `ThisItem.Bild` · X `0` · Y `0` · Width `Parent.TemplateWidth - 8` · Height `Parent.TemplateHeight - 8` · ImagePosition „Ausfüllen“. Im Baum **unter** btnKaFotoEntfernen anordnen, damit das ✕ oben liegt.

**7. scrKategorie → btnKaSpeichern → OnSelect** – komplett ersetzen (lädt Fotos vor dem Speichern hoch; schon hochgeladene werden bei einem zweiten Versuch nicht erneut gesendet):
```
If(
    // (9) noch etwas offen → zum ersten offenen Punkt springen und offene Karten rot markieren
    Value(lblKaFehlendAnzahl.Text) > 0;
        Set(varZeigeFehlend; true);;
        Set(varSprungRec; First(Filter(Sort(Filter(colAntworten; !Inaktiv); Reihenfolge); fnFehlt(Typ; Pflicht; Bewertung; WertText; WertZahl; Kommentar))));;
        Reset(galKaPruefpunkte);
    !varIsLoading && Now() >= varSperreBis;
        Set(varIsLoading; true);;
        Set(varPatchFehler; false);;
        Concurrent(Refresh(RG_Durchfuehrungen); Refresh(RG_KategorieErgebnisse));;
        Concurrent(
            ClearCollect(colErledigt; ShowColumns(Filter(RG_KategorieErgebnisse; DurchfuehrungID = varDurchID); ID; KategorieID; AnzahlNIO; GespeichertAm; PrueferName));
            Set(varDurch; LookUp(RG_Durchfuehrungen; ID = varDurchID))
        );;
        With({durch: varDurch; erg: LookUp(RG_KategorieErgebnisse; Title = varSchluesselK)};
            If(
                CountRows(Filter(colAntworten; !Inaktiv)) = 0;
                    Notify("Diese Kategorie hat keine aktiven Prüfpunkte. Bitte die Stammdaten prüfen lassen."; NotificationType.Error);
                Value(lblKaFehlendAnzahl.Text) > 0;
                    Notify("Bitte noch ausfüllen: " & lblKaFehlend.Text; NotificationType.Warning);
                durch.Status <> stInArbeit;
                    Notify("Der Rundgang ist nicht mehr in Arbeit – Änderungen sind nicht möglich."; NotificationType.Error);
                !IsBlank(erg) && erg.GespeichertAm <> varGespeichertBeimOeffnen;
                    Notify("Diese Kategorie wurde inzwischen von " & erg.PrueferName & " gespeichert. Bitte zurück und neu öffnen."; NotificationType.Error);
                IsBlank(erg) && CountRows(Filter(colKatListe As kl; kl.Position < varKatPos && IsBlank(LookUp(colErledigt As e; e.KategorieID = kl.KategorieID)))) > 0;
                    Notify("Bitte zuerst die vorherigen Kategorien abschließen."; NotificationType.Warning);
                // (F1) neue Fotos hochladen – nur für Punkte, die (noch) n.i.O. sind; schon hochgeladene (Url gesetzt) nicht erneut
                ClearCollect(colFotoNeu; Filter(colFotos As f0; IsBlank(f0.Url) && LookUp(colAntworten As a0; a0.PruefpunktID = f0.PruefpunktID).Bewertung = "NIO"));;
                ForAll(colFotoNeu As f;
                    Patch(colFotos; LookUp(colFotos; Nr = f.Nr);
                        {Url: IfError(RG_Foto_hochladen.Run({contentBytes: f.Bild; name: f.Datei}; f.Datei; fnArchivOrdner(durch.TagText; durch.TestDatensatz) & "/" & durch.Title; varDurchID; f.PruefpunktID; durch.TestDatensatz).url; "")})
                );;
                If(CountRows(Filter(colFotos As f1; IsBlank(f1.Url) && LookUp(colAntworten As a1; a1.PruefpunktID = f1.PruefpunktID).Bewertung = "NIO")) > 0;
                    Notify(CountRows(Filter(colFotos As f2; IsBlank(f2.Url) && LookUp(colAntworten As a2; a2.PruefpunktID = f2.PruefpunktID).Bewertung = "NIO")) & " Foto(s) konnten nicht hochgeladen werden. Bitte „Speichern“ erneut tippen."; NotificationType.Error);
                    // (F2) Links der neuen Fotos an die Antworten hängen (nur einmal je Foto)
                    ForAll(Distinct(Filter(colFotos; !Uebernommen && !IsBlank(Url)); PruefpunktID) As d;
                        Patch(colAntworten; LookUp(colAntworten; PruefpunktID = d.Value);
                            {Fotos: With({alt: LookUp(colAntworten; PruefpunktID = d.Value).Fotos; neu: Concat(Filter(colFotos As x; x.PruefpunktID = d.Value && !x.Uebernommen && !IsBlank(x.Url)); x.Url; " | ")};
                                If(IsBlank(alt); neu; alt & " | " & neu))})
                    );;
                    UpdateIf(colFotos; !Uebernommen && !IsBlank(Url); {Uebernommen: true});;
                    Set(varAntwortJSON; JSON(ShowColumns(colAntworten; PruefpunktID; Frage; Typ; Bewertung; WertZahl; WertText; Einheit; Kommentar; Fotos); JSONFormat.Compact));;
                    IfError(
                        Patch(RG_KategorieErgebnisse; If(IsBlank(erg); Defaults(RG_KategorieErgebnisse); erg);
                            {Title: varSchluesselK; DurchfuehrungID: varDurchID; TagText: durch.TagText; KategorieID: varKatID; Position: varKatPos; BereichName: varBereichName; KategorieName: varKatName; Antworten: varAntwortJSON; AnzahlNIO: CountRows(Filter(colAntworten; Bewertung = "NIO")); PrueferEmail: User().Email; PrueferName: User().FullName; GespeichertAm: Now(); TestDatensatz: durch.TestDatensatz});
                        Set(varPatchFehler; true)
                    );;
                    Refresh(RG_KategorieErgebnisse);;
                    Set(varNachlese; LookUp(RG_KategorieErgebnisse; Title = varSchluesselK));;
                    If(varNachlese.Antworten = varAntwortJSON;
                        Set(varGeaendert; false);;
                        Clear(colFotos);;
                        Notify("Gespeichert."; NotificationType.Success);;
                        // (7) die Übersicht öffnet danach selbst die nächste offene Kategorie
                        Set(varWeiter; true);;
                        Navigate(scrRundgang; ScreenTransition.None);
                        Notify("Speichern wurde nicht bestätigt. Bitte erneut tippen." & If(varPatchFehler; " (SharePoint hat einen Schreibfehler gemeldet – Verbindung prüfen.)"; ""); NotificationType.Error)
                    )
                )
            )
        );;
        Set(varSperreBis; DateAdd(Now(); 2; TimeUnit.Seconds));;
        Set(varIsLoading; false)
)
```
**8. scrRundgang → btnRuAbschluss → OnSelect** – komplett ersetzen (Mängel mit Foto-Links, danach automatisch zum Protokoll):
```
If(!varIsLoading && Now() >= varSperreBis;
    If(!varAbschlussFrage;
        Set(varAbschlussFrage; true);;
        Set(varSperreBis; DateAdd(Now(); 1; TimeUnit.Seconds));
        Set(varAbschlussFrage; false);;
        Set(varIsLoading; true);;
        Set(varPatchFehler; false);;
        Concurrent(Refresh(RG_Durchfuehrungen); Refresh(RG_KategorieErgebnisse));;
        Concurrent(
            Set(varDurch; LookUp(RG_Durchfuehrungen; ID = varDurchID));
            ClearCollect(colErgAlle; Filter(RG_KategorieErgebnisse; DurchfuehrungID = varDurchID))
        );;
        If(IsError(ClearCollect(colKatListe; ForAll(Table(ParseJSON(varDurch.KategorieListe)) As j; {KategorieID: Value(j.Value.KategorieID); Position: Value(j.Value.Position); BereichName: Text(j.Value.BereichName); KategorieName: Text(j.Value.KategorieName)}))); Clear(colKatListe));;
        If(
            !(varDurch.Status in [stInArbeit; stAbschluss]);
                Notify("Dieser Rundgang ist bereits abgeschlossen."; NotificationType.Information);
            CountRows(colKatListe) = 0 || CountRows(colKatListe) <> varDurch.AnzahlKategorien;
                Notify("Die Kategorienliste dieses Rundgangs ist unvollständig. Bitte zurück und erneut öffnen."; NotificationType.Error);
            CountRows(Filter(colKatListe As kl; IsBlank(LookUp(colErgAlle As e; e.KategorieID = kl.KategorieID)))) > 0;
                Notify("Es sind noch nicht alle Kategorien gespeichert."; NotificationType.Warning);
            // (0) Status Abschluss setzen und bestätigen – ab jetzt lehnt SS2 Änderungen ab
            If(varDurch.Status = stInArbeit && IsError(Patch(RG_Durchfuehrungen; LookUp(RG_Durchfuehrungen; ID = varDurchID); {Status: stAbschluss})); Set(varPatchFehler; true));;
            Refresh(RG_Durchfuehrungen);;
            Set(varDurch; LookUp(RG_Durchfuehrungen; ID = varDurchID));;
            If(varDurch.Status <> stAbschluss;
                Notify("Der Rundgang konnte nicht in den Abschluss gesetzt werden. Bitte erneut tippen." & If(varPatchFehler; " (SharePoint hat einen Schreibfehler gemeldet – Verbindung prüfen.)"; ""); NotificationType.Error);
                // (a) Ergebnisse nach dem Statuswechsel lesen: maßgeblicher Stand
                Refresh(RG_KategorieErgebnisse);;
                ClearCollect(colErgAlle; Filter(RG_KategorieErgebnisse; DurchfuehrungID = varDurchID));;
                If(IsError(
                    ClearCollect(colMaengelSoll;
                        Filter(Ungroup(
                            ForAll(Filter(colErgAlle; AnzahlNIO > 0) As e3;
                                {Zeilen: ForAll(Filter(Table(ParseJSON(e3.Antworten)) As a; Text(a.Value.Bewertung) = "NIO") As n;
                                    {Title: "D" & varDurchID & "-P" & Value(n.Value.PruefpunktID);
                                     PruefpunktID: Value(n.Value.PruefpunktID);
                                     BereichName: e3.BereichName;
                                     KategorieName: e3.KategorieName;
                                     Frage: Left(Text(n.Value.Frage); 255);
                                     Wert: Left(Coalesce(Text(n.Value.WertText); "") & If(IsBlank(n.Value.WertZahl); ""; Text(Value(n.Value.WertZahl)) & " " & Coalesce(Text(n.Value.Einheit); "")); 255);
                                     Kommentar: Coalesce(Text(n.Value.Kommentar); "");
                             FotoUrls: Coalesce(Text(n.Value.Fotos); "")})}
                            );
                            Zeilen
                        ); !IsBlank(PruefpunktID))
                    ));
                    Clear(colMaengelSoll)
                );;
                If(Sum(colErgAlle; AnzahlNIO) <> CountRows(colMaengelSoll);
                    Notify("Die Mängel ließen sich nicht vollständig aus den Antworten ermitteln (" & CountRows(colMaengelSoll) & " von " & Sum(colErgAlle; AnzahlNIO) & "). Bitte den Rundgang melden."; NotificationType.Error);
                    // (b) fehlende Mängel anlegen (Schlüssel D…-P…, wiederholbar)
                    Refresh(RG_Maengel);;
                    ClearCollect(colMaengelIst; ShowColumns(Filter(RG_Maengel; DurchfuehrungID = varDurchID); Title));;
                    IfError(
                        Collect(RG_Maengel;
                            ForAll(Filter(colMaengelSoll As s; IsBlank(LookUp(colMaengelIst As i; i.Title = s.Title))) As m;
                                {Title: m.Title; DurchfuehrungID: varDurchID; PruefpunktID: m.PruefpunktID; RundgangName: varDurch.RundgangName; BereichName: m.BereichName; KategorieName: m.KategorieName; Frage: m.Frage; Wert: m.Wert; Kommentar: m.Kommentar; FotoUrls: m.FotoUrls; FestgestelltAm: Now(); FestgestelltVon: User().Email; Status: {Value: "Offen"}; TestDatensatz: varDurch.TestDatensatz})
                        );
                        Set(varPatchFehler; true)
                    );;
                    // Nachlese: Mängel vollständig? Ergebnisse unverändert seit (a)?
                    Concurrent(Refresh(RG_Maengel); Refresh(RG_KategorieErgebnisse); Refresh(RG_Durchfuehrungen));;
                    Concurrent(
                        ClearCollect(colMaengelIst; ShowColumns(Filter(RG_Maengel; DurchfuehrungID = varDurchID); Title));
                        ClearCollect(colErgJetzt; ShowColumns(Filter(RG_KategorieErgebnisse; DurchfuehrungID = varDurchID); ID; GespeichertAm))
                    );;
                    If(
                        CountRows(Filter(colMaengelSoll As s2; IsBlank(LookUp(colMaengelIst As i2; i2.Title = s2.Title)))) > 0;
                            Notify("Die Mängel konnten nicht vollständig gespeichert werden. Bitte „Rundgang abschließen“ erneut tippen." & If(varPatchFehler; " (SharePoint hat einen Schreibfehler gemeldet – Verbindung prüfen.)"; ""); NotificationType.Error);
                        Concat(Sort(colErgJetzt; ID); ID & "@" & Text(GespeichertAm; "yyyy-mm-dd hh:mm:ss"); ";") <> Concat(Sort(colErgAlle; ID); ID & "@" & Text(GespeichertAm; "yyyy-mm-dd hh:mm:ss"); ";");
                            Notify("Während des Abschlusses wurde eine Kategorie gespeichert. Bitte „Rundgang abschließen“ erneut tippen."; NotificationType.Warning);
                        LookUp(RG_Durchfuehrungen; ID = varDurchID).Status <> stAbschluss;
                    Notify("Der Abschluss wurde inzwischen zurückgesetzt. Bitte die Übersicht neu öffnen."; NotificationType.Warning);
                // (c) Abgeschlossen + Nachlese
                        IfError(Patch(RG_Durchfuehrungen; LookUp(RG_Durchfuehrungen; ID = varDurchID); {Status: stAbgeschlossen; EndeZeit: Now(); AnzahlNIO: CountRows(colMaengelSoll)}); Set(varPatchFehler; true));;
                        Refresh(RG_Durchfuehrungen);;
                        Set(varDurch; LookUp(RG_Durchfuehrungen; ID = varDurchID));;
                        If(varDurch.Status = stAbgeschlossen;
                            Notify("Rundgang abgeschlossen · " & CountRows(colMaengelSoll) & " Mängel erfasst. Protokoll wird archiviert …"; NotificationType.Success);;
                                Set(varArchivStart; false);;
                                Navigate(scrProtokoll; ScreenTransition.None);
                            Notify("Der Abschluss wurde nicht bestätigt. Bitte erneut versuchen." & If(varPatchFehler; " (SharePoint hat einen Schreibfehler gemeldet – Verbindung prüfen.)"; ""); NotificationType.Error)
                        )
                    )
                )
            )
        );;
        Set(varSperreBis; DateAdd(Now(); 2; TimeUnit.Seconds));;
        Set(varIsLoading; false)
    )
)
```
**9. scrRundgang → btnRuProtokoll → Text:**
```
"Protokoll" & If(IsBlank(varDurch.ProtokollUrl); "  ⚠"; "") & "  ›"
```
**10. scrProtokoll → OnVisible** – komplett ersetzen:
```
Set(varIsLoading; true);;
Set(varArchivStart; false);;
Set(varProtokollZeit; Now());;
Concurrent(Refresh(RG_KategorieErgebnisse); Refresh(RG_Durchfuehrungen));;
Concurrent(
    Set(varDurch; LookUp(RG_Durchfuehrungen; ID = varDurchID));
    ClearCollect(colErgProt; Filter(RG_KategorieErgebnisse; DurchfuehrungID = varDurchID))
);;
Set(varIsLoading; false);;
// automatisch archivieren, wenn abgeschlossen und noch kein PDF (Timer gibt dem HTML-Text Zeit zum Aufbauen)
Set(varArchivStart; varDurch.Status = stAbgeschlossen && IsBlank(varDurch.ProtokollUrl))
```
**11. htmProtokoll → HtmlText** – komplett ersetzen (mit Foto-Links und Archiv-Link):
```
With({d: varDurch};
    "<div style='font-family:Segoe UI,Arial,sans-serif;font-size:14px;color:#1B1B1F'>" &
    "<div style='background:#171496;color:#ffffff;padding:14px 16px'>" &
        "<div style='font-size:20px;font-weight:600'>" & fnHtml(d.RundgangName) & "</div>" &
        "<div>" & fnTagAnzeige(DateValue(d.TagText)) & " · Prüfer: " & fnHtml(d.PrueferName) & "</div>" &
        "<div>Status: " & d.Status & " · Beginn " & Text(d.StartZeit; "hh:mm") & If(IsBlank(d.EndeZeit); ""; " · Ende " & Text(d.EndeZeit; "hh:mm")) & " · <b>" & Coalesce(d.AnzahlNIO; 0) & " n.i.O.</b></div>" &
    "</div>" &
    Concat(Sort(colErgProt; Position) As e;
        "<h3 style='margin:18px 0 6px 0;font-size:16px;color:#171496'>" & e.Position & ". " & fnHtml(e.KategorieName) &
        " <span style='font-weight:400;color:#5F6370;font-size:13px'>" & fnHtml(e.BereichName) & " · " & fnHtml(e.PrueferName) & " · " & Text(e.GespeichertAm; "hh:mm") & "</span></h3>" &
        "<table style='width:100%;border-collapse:collapse;table-layout:fixed'>" &
        Concat(Table(ParseJSON(e.Antworten)) As a;
            With({b: Text(a.Value.Bewertung); k: Text(a.Value.Kommentar); fo: Text(a.Value.Fotos)};
                "<tr style='border-bottom:1px solid #DADCE5;" & If(b = "NIO"; "background:#FCE8E6;"; "") & "'>" &
                "<td style='padding:6px 8px;width:46%'>" & fnHtml(Text(a.Value.Frage)) & "</td>" &
                "<td style='padding:6px 8px;width:64px;white-space:nowrap;font-weight:600;color:" & If(b = "NIO"; "#B3261E"; "#0F7B3F") & "'>" & Switch(b; "IO"; "i.O."; "NIO"; "n.i.O."; "") & "</td>" &
                "<td style='padding:6px 8px'>" & fnHtml(Text(a.Value.WertText)) & If(IsBlank(a.Value.WertZahl); ""; Text(Value(a.Value.WertZahl)) & " " & fnHtml(Text(a.Value.Einheit))) &
                If(IsBlank(k) || k = ""; ""; "<br><i style='color:#B3261E'>" & fnHtml(k) & "</i>") &
                If(IsBlank(fo) || fo = ""; ""; "<br>" & Concat(Split(fo; " | ") As s; "<a href='" & Trim(s.Value) & "'>📷 Foto</a> ")) &
                "</td></tr>"
            )
        ) & "</table>"
    ) &
    If(IsBlank(d.ProtokollUrl); ""; "<p style='font-size:12px'>Archiv-PDF: <a href='" & d.ProtokollUrl & "'>" & fnHtml(d.Title) & ".pdf</a></p>") &
    "<p style='color:#5F6370;font-size:12px;margin-top:18px'>Erstellt mit der Rundgang-App · " & Text(varProtokollZeit; "dd.mm.yyyy hh:mm") & If(d.TestDatensatz; " · TESTDATEN"; "") & "</p></div>"
)
```
**12. Archiv-Knopf + Timer:** `fertig\FA_scrProtokoll_Archiv.yaml` → **conPrKopf** markieren → Strg+V (Knopf oben rechts). Den Timer **tmrPrArchiv** danach im Baum auf **scrProtokoll** ziehen (Ausschneiden/Einfügen), falls er im Kopf gelandet ist. Formeln zur Kontrolle:
```
If(!IsBlank(varDurch.ProtokollUrl);
    Launch(varDurch.ProtokollUrl);
  !varIsLoading && Now() >= varSperreBis && varDurch.Status = stAbgeschlossen;
    Set(varIsLoading; true);;
    Set(varPatchFehler; false);;
    With({url: IfError(
                RG_Protokoll_archivieren.Run(
                    htmProtokoll.HtmlText;
                    fnDateiname(varDurch.Title & " " & varDurch.RundgangName) & " " & Text(Now(); "yyyymmdd-hhmmss") & ".pdf";
                    fnArchivOrdner(varDurch.TagText; varDurch.TestDatensatz);
                    varDurchID;
                    varDurch.TestDatensatz
                ).url;
                "")};
        If(IsBlank(url);
            Notify("Das Protokoll konnte nicht archiviert werden. Bitte „Archivieren“ erneut tippen."; NotificationType.Error);
            If(IsError(Patch(RG_Durchfuehrungen; LookUp(RG_Durchfuehrungen; ID = varDurchID); {ProtokollUrl: url; ProtokollErstelltAm: Now()})); Set(varPatchFehler; true));;
            Refresh(RG_Durchfuehrungen);;
            Set(varDurch; LookUp(RG_Durchfuehrungen; ID = varDurchID));;
            If(IsBlank(varDurch.ProtokollUrl);
                Notify("PDF erstellt, aber der Link konnte nicht gespeichert werden. Bitte „Archivieren“ erneut tippen."; NotificationType.Error);
                Notify("Protokoll als PDF archiviert."; NotificationType.Success)
            )
        )
    );;
    Set(varSperreBis; DateAdd(Now(); 2; TimeUnit.Seconds));;
    Set(varIsLoading; false)
)
```
```
Set(varArchivStart; false);;
If(varDurch.Status = stAbgeschlossen && IsBlank(varDurch.ProtokollUrl) && CountRows(colErgProt) > 0;
    // Sperre aus dem Abschluss-Knopf aufheben, sonst greift das automatische Archivieren nicht
    Set(varSperreBis; Now());;
    Select(btnPrArchivieren)
)
```

App-Überprüfung → Formeln 0 → speichern.

---

## FA5 – Test (mit ZZ-Testdaten)
1. Rundgang starten → K1: einen Punkt n.i.O. → „📷 Foto“ → 2 Fotos aufnehmen → eins entfernen → Fertig → Knopf zeigt „📷 Foto (1)“.
2. Speichern → „Bitte warten“ etwas länger → gespeichert. In **RG_Fotos/TEST/2026/10/R…/** liegt 1 Foto mit DurchfuehrungID/PruefpunktID.
3. K1 erneut öffnen → „📷 Foto (1)“ → „Gespeichertes Foto öffnen“ öffnet das Bild.
4. Alle Kategorien speichern → Abschluss → App springt zum Protokoll → nach ~1–3 s „Protokoll als PDF archiviert“, oben „✓ Archiv-PDF öffnen“ → PDF in **RG_Protokolle/TEST/2026/10/** enthält alle Kategorien, n.i.O. rot, „📷 Foto“-Link.
5. RG_Maengel: Zeile des Mangels hat `FotoUrls`. RG_Durchfuehrungen: `ProtokollUrl` und `ProtokollErstelltAm` gefüllt.
6. Fehlerfall: Flow RG_Protokoll_archivieren kurz ausschalten → Abschluss eines zweiten Testrundgangs → Meldung „konnte nicht archiviert werden“, Knopf „⚠ Archivieren“; Flow einschalten → Knopf tippen → archiviert.
7. Danach Testdateien in `TEST/`-Ordnern und Testzeilen löschen.

## FA6 – Rückweg
App: Formeln aus `C:\rundgang_work\app\yaml\` (Stand 25.10.) bzw. Git zurückspielen, btnKaFoto/conKaFoto/btnPrArchivieren/tmrPrArchiv löschen. Flows ausschalten/löschen. Bibliotheken und Spalten können bleiben (stören nicht) oder gelöscht werden.

## Zeitbedarf und Performance (geschlussfolgert)
- Speichern ohne Fotos: unverändert (~2,6 s). Je Foto ca. +1–3 s (Größe/Netz).
- Archivieren: ca. 3–8 s im Hintergrund nach dem Abschluss (Flow mit Umwandlung); die App bleibt bedienbar, sobald „Bitte warten“ verschwindet.
