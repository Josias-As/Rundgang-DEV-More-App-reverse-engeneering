# ANLEITUNG JOSIAS – Tablet-Test (J1)

**Voraussetzung:** App „Rundgang DEV“ ist veröffentlicht (siehe FRAGEN F2). Testdaten: Rundgang „ZZ Test Objektrundgang TCC“ ist jeden **Sonntag** und **jeden zweiten Montag** (ab 19.10.) fällig – an anderen Tagen zeigt der Start „Für diesen Tag ist kein Rundgang geplant“. Für einen Test an einem anderen Tag sag mir Bescheid, dann lege ich einen passenden Testplan an.

## Ablauf (ca. 10 Minuten)
1. Tablet: **Power Apps**-App öffnen (oder Browser `make.powerapps.com` → Apps → Rundgang DEV → Wiedergeben).
2. **Hochformat** und **Querformat** drehen – passt alles, nichts abgeschnitten?
3. Rundgang **Starten** → Kategorie 1 öffnen.
4. i.O./n.i.O. mit dem **Finger** (und wenn möglich mit **Handschuh**) tippen – groß genug?
5. Bei n.i.O. **Kommentar** eintippen – Tastatur verdeckt nichts Wichtiges?
6. In Kategorie 3 bei der Wassertemperatur nacheinander eingeben: `13,2` (soll angenommen werden, i.O.), `19.653` (Tausenderpunkt – was zeigt das Tablet?), `abc` (darf nicht angenommen werden).
7. Speichern → nächste Kategorie frei? Am Ende **Rundgang abschließen** (zweimal tippen).

## Rückmeldung
Einfach kurz schreiben, was auffällt (Foto/Screenshot hilft). Testdaten räume ich danach selbst auf.
