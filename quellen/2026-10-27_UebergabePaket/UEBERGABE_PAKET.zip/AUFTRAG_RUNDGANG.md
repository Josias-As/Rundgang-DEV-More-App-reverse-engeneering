# Auftrag: Rundgangs-App V1 bauen (verbindlich)

Stand 25.10.2026 · Auftraggeber Josias Assefaw · Ausführung: Claude (Desktop-App-Chat), selbstständig im Browser.
Fachgrundlage: Vault `Rundgang/01_Planung_2026-10-25/` (01_KONZEPT, 02_ENTSCHEIDUNGEN_UND_FRAGEN, 04/05 Prüfungen). Vorbild für die Arbeitsweise: Handy-App Tischbuchung (`Tischbuchung/05_HANDY_APP/`).
Josias (25.10.): „Wenn du vorsichtig vorgehst und alles genau dokumentierst, kannst du so gut wie alles machen, was uns weiterbringt. Ich möchte so wenig wie möglich freigeben müssen.“

## 1. Ziel
Canvas-App `Rundgang DEV` (Tablet, Hochformat) auf den Listen `RG_…` der Site `https://technoformgroup.sharepoint.com/sites/IMSKonzept`, die Konzept V1 umsetzt: Tag wählen → fälliger Rundgang → Kategorien nur der Reihe nach → je Kategorie Prüfpunkte erfassen und speichern → Abschluss mit Mängelliste und Protokoll-Mail (Testmodus).

## 2. Leitplanken (ohne Ausnahme)
- **L1** Bearbeitet wird nur die App `Rundgang DEV` (App-ID `1b9800f7-8289-4ee8-b720-cef0bbf1eae1`, Umgebung `Default-84e2e900-49ec-4416-85fb-299b258a5227` „Personal Productivity“). Keine andere App bearbeiten, speichern oder veröffentlichen. Bei „Speichern unter“ nie „Vorhandene ersetzen“.
- **L2** SharePoint: Daten nur in Listen mit Marke `ZZ_RG_P0`. Struktur nur über `bau/schema` + Skript (nie von Hand). Schutzliste nie anfassen.
- **L3** Nur Testdaten (`ZZ Test …`, `TestDatensatz = Ja`). Mails nur im Testmodus an die Testadresse. Gelöscht werden nur eigene, in `TESTDATEN.md` protokollierte Testzeilen.
- **L4** Keine Flows, keine Rechteänderungen, App nicht teilen.
- **L5** Keine Passwörter/MFA eingeben; Anmeldung macht Josias.
- **L6** Jeder Schritt in `FORTSCHRITT.md` (vorher/nachher/Rückweg), Belege in `TESTPROTOKOLL.md`, Git-Commit. „Bestanden“ nur mit Beleg (G13).
- **L7** Pakete atomar (nichts halb einbauen, HAN-15). Ab 10 Properties oder neuen Schreibstellen unabhängiger Prüf-Agent vor dem Abschluss des Pakets (R37).
- **L8** Fachfragen blockieren nicht: Arbeitsannahme aus `02_ENTSCHEIDUNGEN_UND_FRAGEN.md`, offene Punkte in `FRAGEN_AN_JOSIAS.md`.

## 3. Kriterien
| ID | Kriterium |
|---|---|
| R01 | Listen auf IMSKonzept angelegt und per Rückgabe gegen das Schema geprüft: „OK“ |
| R02 | App `Rundgang DEV` angelegt (Tablet, Hochformat, „An Bildschirm anpassen“ aus), App-ID dokumentiert |
| R03 | App-Einstellungen dokumentiert (Datenzeilenlimit 2000, Analyse-Engine/UDF, Formelsprache Deutsch) |
| R04 | Datenquellen: alle 9 `RG_`-Listen verbunden; Konnektorstufe Office 365 Outlook/Users dokumentiert |
| R05 | Vorab-Tests im Browser belegt: UDF, `JSON` mit Dezimalzahl, `ParseJSON`, `DateDiff` über Zeitumstellung, Nur-Datum `StartMontag` |
| R06 | `App.Formulas` (Konstanten, Kataloge, UDFs) ohne Formelfehler |
| R07 | scrStart: Tagesauswahl (heute + `NachholTage`), KW/Wochentag berechnet; fällige Rundgänge nach Planregel. Belege: 25.10. „ZZ Test So“ fällig, 26.10. nicht fällig, 02.11. fällig |
| R08 | SS1 Starten/Fortsetzen mit fünf Schutzschichten; Doppeltipp → genau eine Durchführung (REST-Nachlese) |
| R09 | scrRundgang: Kategorien in Reihenfolge aus `KategorieListe`, Status erledigt / als Nächstes / gesperrt; gesperrte über keine Einstiegsfläche öffenbar |
| R10 | scrKategorie: nur aktive Prüfpunkte der Kategorie; Eingabetypen IONIO, AUSWAHL, ZAHL, TEXT bedienbar |
| R11 | Speichern nur bei vollständiger Kategorie; n.i.O. verlangt Kommentar; Zahl außerhalb Min/Max wird n.i.O. |
| R12 | SS2: genau eine Zeile je Kategorie, Nachlese = gesendeter JSON-Text; Doppeltipp → eine Zeile; danach ist die nächste Kategorie frei |
| R13 | Öffnen, ändern, zurück, andere Kategorie öffnen → keine Restwerte |
| R14 | Zweites Fenster speichert dieselbe Kategorie → Meldung, kein stilles Überschreiben |
| R15 | SS3: Status `Abschluss` → Mängel aus allen n.i.O. (Wiederholung ohne Dubletten) → `Abgeschlossen`; Nachlese |
| R16 | SS4: HTML-Protokoll-Mail im Testmodus an die Testadresse; Konfigurationszeile `Testmodus` fehlt → trotzdem Testmodus |
| R17 | Nach Abschluss keine Änderung an Kategorien möglich |
| R18 | App-Prüfung: 0 Formelfehler; Delegationswarnungen 0 oder begründet |
| R19 | Unabhängiger Prüf-Agent auf alle Schreibformeln; jeder Befund behoben oder in `ENTSCHEIDUNGEN.md` begründet |
| R20 | Livemonitor-Messung Start und Kategorie-Speichern dokumentiert |
| R21 | Eigene Test-Bewegungsdaten protokolliert und am Ende gelöscht (Nachlese) |
| R22 | Doku aktuell: FORTSCHRITT, ENTSCHEIDUNGEN, TESTPROTOKOLL, TESTDATEN, FRAGEN_AN_JOSIAS, ANLEITUNG_JOSIAS (Tablet-Tests), Vault-Index; Git-Commit |
| J1 | (Josias) Test auf dem Tablet: Größe hoch/quer, Zahleingabe „13,2“/„19.653“, Bedienung mit Handschuh/Finger |
| J2 | (Josias/Fachbereich) Netz auf der Rundgangsstrecke (RG-RA2) |
| J3 | (Fachbereich) echte Rundgänge, Bereiche, Kategorien, Prüfpunkte (RG-F2) |
