# Paket K – Kern-Verbesserungen (Punkte 2, 3, 7, 8, 9)

Stand 26.10.2026 · passend zum App-Stand vom 25.10. **Voraussetzung: CP0 aus `CODE_PAKETE.md`.** Empfohlene Reihenfolge insgesamt: **CP0 → CP1 → K → (CP3, CP4) → FA → CP2**. Paket FA baut ab jetzt auf K auf (seine Formeln enthalten K schon).

| Nr | Was | Wo |
|---|---|---|
| **2** | Admin-Ausweg: hängt ein Abschluss („Abschluss begonnen, aber nicht beendet“), setzt ein Admin den Rundgang mit zweitem Tippen auf „In Arbeit“ zurück; vorläufige Mängel werden dabei entfernt und beim nächsten Abschluss neu erzeugt | scrRundgang, Kopf rechts |
| **3** | Nur-Ansicht zeigt **genau das Gespeicherte** (aus dem JSON), auch wenn Prüfpunkte inzwischen geändert/deaktiviert sind. Beim Bearbeiten bleiben Antworten deaktivierter Prüfpunkte erhalten (ausgeblendet) | scrKategorie.OnVisible |
| **7** | **„Speichern & weiter“**: nach dem Speichern öffnet sich direkt die nächste offene Kategorie. Sind alle erledigt → Übersicht mit Abschluss | btnKaSpeichern, scrRundgang.OnVisible |
| **8** | Prüfpunktliste beginnt beim Öffnen **immer oben** | scrKategorie |
| **9** | **Fortschritt** im Kopf („5 von 8 ausgefüllt“) + Balken; ist noch etwas offen, wird der Speichern-Knopf zu **„Offene Punkte ↓“**: springt zum ersten offenen Punkt und rahmt alle offenen Karten rot | scrKategorie |

**Einfügen wie gehabt:** YAML aus `pakete\fertig\` (Editor → Strg+A/C → Ziel im Baum markieren → Strg+V), Formeln in der Formelleiste in der hier abgedruckten deutschen Fassung. Vorher Vorschau beenden, nachher App-Überprüfung (Formeln 0) und speichern.

---

## K0 – Vorbereitung

**SharePoint, Liste RG_Konfiguration:** neue Zeile · Titel `Admins` · Wert: E-Mail-Adressen der Admins, getrennt mit `;` (z. B. deine Adresse).

**App → Formulas** – ans Ende anhängen:
```
cfgAdmins = Coalesce(LookUp(RG_Konfiguration; Title = "Admins").Wert; "");;
fnFehlt(typ: Text; pflicht: Boolean; bew: Text; wt: Text; wz: Number; kom: Text): Boolean = (pflicht && ((typ = "IONIO" && bew = "") || (typ = "AUSWAHL" && wt = "") || (typ = "ZAHL" && IsBlank(wz)) || (typ = "TEXT" && Trim(wt) = ""))) || (bew = "NIO" && Trim(kom) = "");;
```
**App → OnStart** – ans Ende anhängen (vorher `;;` an die letzte Zeile):
```
Set(varIstAdmin; CountRows(Filter(Split(Lower(cfgAdmins); ";") As a; Trim(a.Value) = Lower(User().Email))) > 0);;
Set(varZuruecksetzenFrage; false);;
Set(varWeiter; false);;
Set(varZeigeFehlend; false);;
```
Danach „OnStart ausführen“.

---

## K1 – Kategorie-Screen (Punkte 3, 8, 9)

1. **scrKategorie → OnVisible** komplett ersetzen:
```
Set(varIsLoading; true);;
Set(varZurueckFrage; false);;
Set(varAlleIOFrage; false);;
Set(varZeigeFehlend; false);;
Set(varGeaendert; false);;
Set(varSchluesselK; "D" & varDurchID & "-K" & varKatID);;
Set(varNurLesen; varDurch.Status <> stInArbeit);;
Refresh(RG_KategorieErgebnisse);;
Concurrent(
    ClearCollect(colPP; Filter(RG_Pruefpunkte; KategorieID = varKatID && Aktiv = true));
    Set(varErgebnis; LookUp(RG_KategorieErgebnisse; Title = varSchluesselK))
);;
Set(varGespeichertBeimOeffnen; varErgebnis.GespeichertAm);;
With({t: If(IsBlank(varErgebnis.Antworten); Table(ParseJSON("[]")); Table(ParseJSON(varErgebnis.Antworten)))};
    If(varNurLesen && !IsEmpty(t);
        // (3) Nur-Ansicht: genau das anzeigen, was gespeichert wurde (unabhängig von späteren Stammdaten-Änderungen)
        ClearCollect(colAntworten;
            ForAll(Sequence(CountRows(t)) As i;
                With({a: Index(t; i.Value).Value};
                    With({pp: LookUp(colPP; ID = Value(a.PruefpunktID))};
                        {PruefpunktID: Value(a.PruefpunktID); Frage: Text(a.Frage); Typ: Text(a.Typ); Pflicht: false; Einheit: Coalesce(Text(a.Einheit); ""); MinWert: pp.MinWert; MaxWert: pp.MaxWert; Auswahl: Coalesce(Text(a.WertText); ""); Hinweis: ""; Reihenfolge: i.Value;
                         Bewertung: Coalesce(Text(a.Bewertung); ""); WertText: Coalesce(Text(a.WertText); ""); WertZahl: Value(a.WertZahl); Kommentar: Coalesce(Text(a.Kommentar); ""); Fotos: Coalesce(Text(a.Fotos); ""); Inaktiv: false}
                    )
                )
            )
        );
        // Bearbeiten: aktive Prüfpunkte aus den Stammdaten, vorbelegt aus dem gespeicherten JSON
        ClearCollect(colAntworten;
            ForAll(Sort(colPP; RgReihenfolge) As p;
                With({alt: LookUp(t As j; Value(j.Value.PruefpunktID) = p.ID)};
                    {PruefpunktID: p.ID; Frage: p.Title; Typ: p.Eingabetyp.Value; Pflicht: p.Pflicht; Einheit: Coalesce(p.Einheit; ""); MinWert: p.MinWert; MaxWert: p.MaxWert; Auswahl: Coalesce(p.Auswahlwerte; ""); Hinweis: Coalesce(p.Hinweis; ""); Reihenfolge: p.RgReihenfolge;
                     Bewertung: If(IsBlank(alt); ""; p.Eingabetyp.Value = "ZAHL" && !IsBlank(alt.Value.WertZahl); fnZahlBewertung(Value(alt.Value.WertZahl); p.MinWert; p.MaxWert); Coalesce(Text(alt.Value.Bewertung); ""));
                     WertText: If(IsBlank(alt); ""; Coalesce(Text(alt.Value.WertText); ""));
                     WertZahl: If(IsBlank(alt); Blank(); Value(alt.Value.WertZahl));
                     Kommentar: If(IsBlank(alt); ""; Coalesce(Text(alt.Value.Kommentar); ""));
                     Fotos: If(IsBlank(alt); ""; Coalesce(Text(alt.Value.Fotos); ""));
                     Inaktiv: false}
                )
            )
        );;
        // (3b) Antworten inzwischen deaktivierter Prüfpunkte unverändert mitführen: ausgeblendet, gehen beim Speichern nicht verloren
        Collect(colAntworten;
            ForAll(Filter(t As j2; IsBlank(LookUp(colPP; ID = Value(j2.Value.PruefpunktID)))) As o;
                {PruefpunktID: Value(o.Value.PruefpunktID); Frage: Text(o.Value.Frage); Typ: Text(o.Value.Typ); Pflicht: false; Einheit: Coalesce(Text(o.Value.Einheit); ""); MinWert: Blank(); MaxWert: Blank(); Auswahl: ""; Hinweis: ""; Reihenfolge: 100000 + Value(o.Value.PruefpunktID);
                 Bewertung: Coalesce(Text(o.Value.Bewertung); ""); WertText: Coalesce(Text(o.Value.WertText); ""); WertZahl: Value(o.Value.WertZahl); Kommentar: Coalesce(Text(o.Value.Kommentar); ""); Fotos: Coalesce(Text(o.Value.Fotos); ""); Inaktiv: true}
            )
        )
    )
);;
// (8) Liste immer oben beginnen
Set(varSprungRec; First(Sort(Filter(colAntworten; !Inaktiv); Reihenfolge)));;
Reset(galKaPruefpunkte);;
Set(varIsLoading; false)
```
2. **galKaPruefpunkte → Items:**
```
Sort(Filter(colAntworten; !Inaktiv); Reihenfolge)
```
3. **galKaPruefpunkte → Default:**
```
varSprungRec
```
4. **lblKaFehlendAnzahl → Text:**
```
CountRows(Filter(colAntworten; !Inaktiv && fnFehlt(Typ; Pflicht; Bewertung; WertText; WertZahl; Kommentar)))
```
5. **lblKaFehlend → Text:**
```
Concat(Filter(Sort(colAntworten; Reihenfolge); !Inaktiv && fnFehlt(Typ; Pflicht; Bewertung; WertText; WertZahl; Kommentar)); Frage & If(Bewertung = "NIO" && Trim(Kommentar) = ""; " (Kommentar)"; ""); "; ")
```
6. **lblKaUnter → Text** (Fortschritt im Kopf):
```
varBereichName & "  ·  Kategorie " & varKatPos & " von " & CountRows(colKatListe) &
If(varNurLesen; "  ·  nur Ansicht";
    "  ·  " & (CountRows(Filter(colAntworten; !Inaktiv)) - Value(lblKaFehlendAnzahl.Text)) & " von " & CountRows(Filter(colAntworten; !Inaktiv)) & " ausgefüllt")
```
7. **conKaKarte → BorderColor:**
```
If(ThisItem.Bewertung = "NIO" || (varZeigeFehlend && fnFehlt(ThisItem.Typ; ThisItem.Pflicht; ThisItem.Bewertung; ThisItem.WertText; ThisItem.WertZahl; ThisItem.Kommentar)); clrFehler; clrRahmen)
```
   **conKaKarte → BorderThickness:**
```
If(ThisItem.Bewertung = "NIO" || (varZeigeFehlend && fnFehlt(ThisItem.Typ; ThisItem.Pflicht; ThisItem.Bewertung; ThisItem.WertText; ThisItem.WertZahl; ThisItem.Kommentar)); 2; 1)
```
8. **Fortschrittsbalken:** `fertig\K_conKaBalken.yaml` → **scrKategorie** markieren → Strg+V (liegt direkt unter dem blauen Kopf, Y 136).
9. **lblKaStand → Text** (zählt ausgeblendete Antworten nicht mit):
```
If(varNurLesen; "Nur Ansicht – der Rundgang ist nicht mehr in Arbeit.";
    Value(lblKaFehlendAnzahl.Text) = 0; "✓  Alles ausgefüllt" & With({n: CountRows(Filter(colAntworten; !Inaktiv && Bewertung = "NIO"))}; If(n > 0; " · " & n & " n.i.O."; ""));
    "Noch offen (" & lblKaFehlendAnzahl.Text & "): " & lblKaFehlend.Text)
```

## K2 – Speichern-Knopf (Punkte 7, 9)

**btnKaSpeichern:**
- **OnSelect** komplett ersetzen:
```
If(
    // (9) noch etwas offen → zum ersten offenen Punkt springen und offene Karten rot markieren
    Value(lblKaFehlendAnzahl.Text) > 0;
        Set(varZeigeFehlend; true);;
        Set(varSprungRec; First(Filter(Sort(Filter(colAntworten; !Inaktiv); Reihenfolge); fnFehlt(Typ; Pflicht; Bewertung; WertText; WertZahl; Kommentar))));;
        Reset(galKaPruefpunkte);
    !varIsLoading && Now() >= varSperreBis;
        Set(varIsLoading; true);;
        Set(varPatchFehler; false);;
        Concurrent(Refresh(RG_Durchfuehrungen); Refresh(RG_KategorieErgebnisse));;
        Concurrent(
            ClearCollect(colErledigt; ShowColumns(Filter(RG_KategorieErgebnisse; DurchfuehrungID = varDurchID); ID; KategorieID; AnzahlNIO; GespeichertAm; PrueferName));
            Set(varDurch; LookUp(RG_Durchfuehrungen; ID = varDurchID))
        );;
        With({durch: varDurch; erg: LookUp(RG_KategorieErgebnisse; Title = varSchluesselK)};
            If(
                CountRows(Filter(colAntworten; !Inaktiv)) = 0;
                    Notify("Diese Kategorie hat keine aktiven Prüfpunkte. Bitte die Stammdaten prüfen lassen."; NotificationType.Error);
                Value(lblKaFehlendAnzahl.Text) > 0;
                    Notify("Bitte noch ausfüllen: " & lblKaFehlend.Text; NotificationType.Warning);
                durch.Status <> stInArbeit;
                    Notify("Der Rundgang ist nicht mehr in Arbeit – Änderungen sind nicht möglich."; NotificationType.Error);
                !IsBlank(erg) && erg.GespeichertAm <> varGespeichertBeimOeffnen;
                    Notify("Diese Kategorie wurde inzwischen von " & erg.PrueferName & " gespeichert. Bitte zurück und neu öffnen."; NotificationType.Error);
                IsBlank(erg) && CountRows(Filter(colKatListe As kl; kl.Position < varKatPos && IsBlank(LookUp(colErledigt As e; e.KategorieID = kl.KategorieID)))) > 0;
                    Notify("Bitte zuerst die vorherigen Kategorien abschließen."; NotificationType.Warning);
                Set(varAntwortJSON; JSON(ShowColumns(colAntworten; PruefpunktID; Frage; Typ; Bewertung; WertZahl; WertText; Einheit; Kommentar; Fotos); JSONFormat.Compact));;
                IfError(
                    Patch(RG_KategorieErgebnisse; If(IsBlank(erg); Defaults(RG_KategorieErgebnisse); erg);
                        {Title: varSchluesselK; DurchfuehrungID: varDurchID; TagText: durch.TagText; KategorieID: varKatID; Position: varKatPos; BereichName: varBereichName; KategorieName: varKatName; Antworten: varAntwortJSON; AnzahlNIO: CountRows(Filter(colAntworten; Bewertung = "NIO")); PrueferEmail: User().Email; PrueferName: User().FullName; GespeichertAm: Now(); TestDatensatz: durch.TestDatensatz});
                    Set(varPatchFehler; true)
                );;
                Refresh(RG_KategorieErgebnisse);;
                Set(varNachlese; LookUp(RG_KategorieErgebnisse; Title = varSchluesselK));;
                If(varNachlese.Antworten = varAntwortJSON;
                    Set(varGeaendert; false);;
                    Notify("Gespeichert."; NotificationType.Success);;
                    // (7) die Übersicht öffnet danach selbst die nächste offene Kategorie
                    Set(varWeiter; true);;
                    Navigate(scrRundgang; ScreenTransition.None);
                    Notify("Speichern wurde nicht bestätigt. Bitte erneut tippen." & If(varPatchFehler; " (SharePoint hat einen Schreibfehler gemeldet – Verbindung prüfen.)"; ""); NotificationType.Error)
                )
            )
        );;
        Set(varSperreBis; DateAdd(Now(); 2; TimeUnit.Seconds));;
        Set(varIsLoading; false)
)
```
- **Text:**
```
If(Value(lblKaFehlendAnzahl.Text) > 0; "Offene Punkte ↓";
    CountRows(Filter(colKatListe As k; k.KategorieID <> varKatID && IsBlank(LookUp(colErledigt As e; e.KategorieID = k.KategorieID)))) > 0; "Speichern & weiter";
    "Speichern")
```
- **Fill:**
```
If(Value(lblKaFehlendAnzahl.Text) > 0; clrPrimaerHell; clrPrimaer)
```
- **Color:**
```
If(Value(lblKaFehlendAnzahl.Text) > 0; clrPrimaer; Color.White)
```
- **DisplayMode:**
```
If(varIsLoading; DisplayMode.Disabled; DisplayMode.Edit)
```

## K3 – Übersicht (Punkte 2, 7)

1. **scrRundgang → OnVisible** komplett ersetzen:
```
If(!varWeiter;
    Set(varIsLoading; true);;
    Set(varAbschlussFrage; false);;
    Set(varZuruecksetzenFrage; false);;
    Concurrent(Refresh(RG_Durchfuehrungen); Refresh(RG_KategorieErgebnisse));;
    Concurrent(
        Set(varDurch; LookUp(RG_Durchfuehrungen; ID = varDurchID));
        ClearCollect(colErledigt; ShowColumns(Filter(RG_KategorieErgebnisse; DurchfuehrungID = varDurchID); ID; KategorieID; AnzahlNIO; GespeichertAm; PrueferName))
    );;
    IfError(ClearCollect(colKatListe; ForAll(Table(ParseJSON(varDurch.KategorieListe)) As j; {KategorieID: Value(j.Value.KategorieID); Position: Value(j.Value.Position); BereichName: Text(j.Value.BereichName); KategorieName: Text(j.Value.KategorieName)})); Clear(colKatListe));;
    If(CountRows(colKatListe) = 0 || CountRows(colKatListe) <> varDurch.AnzahlKategorien; Notify("Die Kategorienliste dieses Rundgangs konnte nicht geladen werden. Bitte zurück und erneut öffnen."; NotificationType.Error));;
    Set(varIsLoading; false)
)
```
2. **Admin-Knopf:** `fertig\K_btnRuZuruecksetzen.yaml` → **conRuKopf** markieren → Strg+V. Formel zur Kontrolle:
```
If(!varIsLoading && Now() >= varSperreBis;
    If(!varZuruecksetzenFrage;
        Set(varZuruecksetzenFrage; true);;
        Set(varSperreBis; DateAdd(Now(); 1; TimeUnit.Seconds));
        Set(varZuruecksetzenFrage; false);;
        Set(varIsLoading; true);;
        Set(varPatchFehler; false);;
        Refresh(RG_Durchfuehrungen);;
        Set(varDurch; LookUp(RG_Durchfuehrungen; ID = varDurchID));;
        If(!varIstAdmin || varDurch.Status <> stAbschluss;
            Notify("Der Rundgang ist nicht (mehr) im Status „Abschluss“ – nichts zu tun."; NotificationType.Information);
            // Schutz: ein Abschluss, der gerade auf einem anderen Tablet läuft, darf nicht zurückgesetzt werden
            DateDiff(varDurch.Modified; Now(); TimeUnit.Minutes) < 5;
            Notify("Der Abschluss wurde vor weniger als 5 Minuten begonnen und läuft evtl. noch auf einem anderen Gerät. Bitte später erneut versuchen."; NotificationType.Warning);
            // vorläufige, noch unbearbeitete Mängel entfernen – sie entstehen beim nächsten Abschluss neu aus den Antworten
            If(IsError(Remove(RG_Maengel; Filter(RG_Maengel; DurchfuehrungID = varDurchID && Status.Value = "Offen"))); Set(varPatchFehler; true));;
            If(IsError(Patch(RG_Durchfuehrungen; LookUp(RG_Durchfuehrungen; ID = varDurchID); {Status: stInArbeit})); Set(varPatchFehler; true));;
            Concurrent(Refresh(RG_Durchfuehrungen); Refresh(RG_Maengel));;
            Concurrent(
                Set(varDurch; LookUp(RG_Durchfuehrungen; ID = varDurchID));
                ClearCollect(colMaengelIst; ShowColumns(Filter(RG_Maengel; DurchfuehrungID = varDurchID && Status.Value = "Offen"); Title))
            );;
            If(varDurch.Status = stInArbeit && IsEmpty(colMaengelIst);
                Notify("Zurückgesetzt – der Rundgang ist wieder in Arbeit. Kategorien können korrigiert und der Abschluss neu gestartet werden."; NotificationType.Success);
                Notify("Zurücksetzen nicht vollständig bestätigt. Bitte erneut versuchen." & If(varPatchFehler; " (SharePoint hat einen Schreibfehler gemeldet – Verbindung prüfen.)"; ""); NotificationType.Error)
            )
        );;
        Set(varSperreBis; DateAdd(Now(); 2; TimeUnit.Seconds));;
        Set(varIsLoading; false)
    )
)
```

---

## K4 – Test
1. **9 + 8:** Kategorie mit 3 Pflichtpunkten öffnen → Kopf „0 von 3 ausgefüllt“, Balken leer, Knopf „Offene Punkte ↓“ (hellblau). Nach unten scrollen, zurück, andere Kategorie öffnen → Liste beginnt oben. Einen Punkt ausfüllen → „1 von 3“. „Offene Punkte ↓“ tippen → springt zum ersten offenen, offene Karten rot umrandet. Alle ausfüllen → Balken grün, Knopf „Speichern & weiter“.
2. **7:** „Speichern & weiter“ → kurz Übersicht → nächste Kategorie öffnet sich automatisch. Letzte Kategorie → Knopf heißt „Speichern“ → bleibt in der Übersicht.
3. **3:** Rundgang abschließen → Kategorie „Ansehen“ → zeigt die gespeicherten Werte. Dann in SharePoint einen Prüfpunkt dieser Kategorie auf Aktiv = Nein → „Ansehen“ zeigt ihn weiterhin (aus dem JSON). Gegenprobe beim Bearbeiten (neuer Testrundgang): Punkt speichern, dann deaktivieren, Kategorie erneut speichern → im JSON (Liste RG_KategorieErgebnisse, Spalte Antworten) ist die Antwort noch drin. Prüfpunkt danach wieder aktivieren.
4. **2:** Testrundgang in SharePoint auf Status `Abschluss` setzen (simuliert den hängenden Abschluss) → Übersicht zeigt das rote Banner und – nur für Admins – „↺ Zurück auf In Arbeit“ → zweimal tippen → Status InArbeit, Mängel dieses Rundgangs entfernt, Kategorien wieder bearbeitbar. Mit einem Nicht-Admin-Konto ist der Knopf unsichtbar.

## K5 – Hinweise
- **UNSICHER (Punkt 8/9):** dass die Galerie beim Zurücksetzen zum Default-Eintrag scrollt, ist das übliche Verhalten, aber in eurer Studio-Version nicht getestet. Falls die Liste nicht springt: es schadet nicht, nur der Sprung fehlt (Rest funktioniert).
- **Punkt 2 löscht Mängel** dieses einen Rundgangs (landen im SharePoint-Papierkorb). Das ist gewollt: sie werden beim nächsten Abschluss aus den dann gültigen Antworten neu angelegt.
- Abgeschlossene Rundgänge wieder öffnen kann der Knopf bewusst **nicht** (Protokoll, Mail und Archiv wären sonst inkonsistent). Bei Bedarf als eigenes Paket.

## K6 – Rückweg
Formeln aus `C:\rundgang_work\app\yaml\` (Stand 25.10.) bzw. `app\ablage\studio_*.yaml` zurückspielen; conKaBalken und btnRuZuruecksetzen löschen. Die Zeile „Admins“ und die neuen Formeln in App.Formulas/OnStart stören nicht.
